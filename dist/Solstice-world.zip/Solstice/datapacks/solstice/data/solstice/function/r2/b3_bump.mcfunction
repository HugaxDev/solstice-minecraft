scoreboard players set #mx sol.var 0
scoreboard players set #my sol.var 3
playsound minecraft:block.anvil.land master @a ~ ~ ~ 0.5 1.5
title @a actionbar {"text":"Clang ! Un mur invisible… le palet revient au départ.","color":"red"}
