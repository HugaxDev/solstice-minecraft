function solstice:r2/solve_c1
function solstice:r2/solve_c2
function solstice:r2/solve_c3
tellraw @a ["",{"text":"[debug] Puits du Fer vacant : l’automate d’Orel résout ses mécanismes.","color":"red"}]
