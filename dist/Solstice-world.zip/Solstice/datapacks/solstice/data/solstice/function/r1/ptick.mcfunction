execute if score @s sol.y matches ..95 run function solstice:r1/cp
