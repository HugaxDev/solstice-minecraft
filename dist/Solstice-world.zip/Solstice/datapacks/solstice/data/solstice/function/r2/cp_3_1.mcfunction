tp @s 2010.5 101 1.5 180 0
spawnpoint @s 2010 101 1
