scoreboard players operation #s sol.var = #gtime sol.var
scoreboard players operation #s sol.var /= #c20 sol.var
scoreboard players operation #h sol.var = #s sol.var
scoreboard players operation #h sol.var /= #c3600 sol.var
scoreboard players operation #mn sol.var = #s sol.var
scoreboard players operation #mn sol.var %= #c3600 sol.var
scoreboard players operation #mn sol.var /= #c60 sol.var
scoreboard players operation #sec sol.var = #s sol.var
scoreboard players operation #sec sol.var %= #c60 sol.var
tellraw @a ["",{"text":"\n══════════  S O L S T I C E  ══════════","color":"gold","bold":true}]
tellraw @a ["",{"text":"      Une aventure pour trois voyageurs","color":"yellow","italic":true}]
tellraw @a ["",{"text":"\nTemps de partie : ","color":"gray"},{"score":{"name":"#h","objective":"sol.var"},"color":"white"},{"text":" h ","color":"gray"},{"score":{"name":"#mn","objective":"sol.var"},"color":"white"},{"text":" min ","color":"gray"},{"score":{"name":"#sec","objective":"sol.var"},"color":"white"},{"text":" s","color":"gray"}]
tellraw @a ["",{"text":"Indices trouvés : ","color":"gray"},{"score":{"name":"#clues","objective":"sol.var"},"color":"white"},{"text":" / 10","color":"gray"}]
tellraw @a ["",{"text":"Morts :","color":"gray"}]
execute as @a run function solstice:end/credit_line
tellraw @a ["",{"text":"\nMaître Orel","color":"gold"},{"text":" — l’horloger qui voulait arrêter le temps","color":"gray"}]
tellraw @a ["",{"text":"Madame Ysolde","color":"dark_purple"},{"text":" — la bibliothécaire","color":"gray"}]
tellraw @a ["",{"text":"Bram","color":"dark_red"},{"text":" — le forgeron","color":"gray"},{"text":"   ·   ","color":"dark_gray"},{"text":"Lise","color":"dark_green"},{"text":" — la jardinière","color":"gray"}]
tellraw @a ["",{"text":"\nConception, construction et tests : générés pour vous trois.","color":"dark_gray","italic":true}]
tellraw @a ["",{"text":"Merci d’avoir joué.  ✦","color":"gold"}]
tellraw @a ["",{"text":"═══════════════════════════════════════\n","color":"gold","bold":true}]
advancement grant @a only solstice:fin
execute as @a at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
