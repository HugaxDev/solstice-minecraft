scoreboard players set #a2s sol.var 1
playsound minecraft:block.amethyst_block.chime master @a ~ ~ ~ 1 1.2
title @a actionbar {"text":"Le vitrail tinte : première couleur acceptée !","color":"gold"}
