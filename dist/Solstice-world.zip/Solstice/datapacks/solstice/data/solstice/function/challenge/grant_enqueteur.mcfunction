advancement grant @a only solstice:challenge/enqueteur
tellraw @a ["",{"text":"★ Défi caché relevé : ","color":"aqua","bold":true},{"text":"Rien ne m’échappe","color":"white"}]
execute as @a run function solstice:challenge/check_all
