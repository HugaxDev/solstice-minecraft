execute if score @s sol.y matches 111..119 if score @s sol.cp matches ..1 run scoreboard players set @s sol.cp 2
execute if score @s sol.y matches 121..129 if score @s sol.cp matches ..2 run scoreboard players set @s sol.cp 3
execute if score @s sol.y matches 131.. run scoreboard players set @s sol.cp 4
