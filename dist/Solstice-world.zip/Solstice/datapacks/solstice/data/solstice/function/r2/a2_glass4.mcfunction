setblock 1990 113 5 blue_stained_glass
