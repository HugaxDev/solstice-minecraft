title @a times 20 70 20
title @a subtitle {"text":"Les trois voyageurs sont arrivés","color":"gray"}
title @a title {"text":"SOLSTICE","color":"gold","bold":true}
execute as @a at @s run playsound minecraft:block.bell.use master @s ~ ~ ~ 1 0.6
