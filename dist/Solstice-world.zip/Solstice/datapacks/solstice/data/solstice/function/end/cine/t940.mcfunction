function solstice:r7/seasons1
function solstice:r7/fireworks
tellraw @a ["",{"text":"Au printemps suivant, Maître Orel rejoignit les saisons. On dit qu’à Brumeval, chaque fleur fait un peu tic-tac.","color":"white","italic":true}]
