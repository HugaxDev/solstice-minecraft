bossbar set solstice:obj players @a
