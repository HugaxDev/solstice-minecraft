function solstice:r0/cp
execute if score #step sol.var matches 0 run function solstice:r0/welcome
effect give @s night_vision infinite 0 true
