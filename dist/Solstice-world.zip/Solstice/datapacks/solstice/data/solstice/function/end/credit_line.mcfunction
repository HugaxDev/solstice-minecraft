tellraw @a ["",{"text":"   • ","color":"dark_gray"},{"selector":"@s","color":"white"},{"text":" : ","color":"gray"},{"score":{"name":"@s","objective":"sol.dall"},"color":"red"}]
