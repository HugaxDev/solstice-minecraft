scoreboard players set #room3 sol.var 5
scoreboard players operation #room3 sol.var -= #c2b sol.var
execute if score #room3 sol.var > #c2s sol.var run scoreboard players operation #room3 sol.var = #c2s sol.var
scoreboard players operation #c2s sol.var -= #room3 sol.var
scoreboard players operation #c2b sol.var += #room3 sol.var
playsound minecraft:item.bucket.fill master @a ~ ~ ~ 0.8 1
function solstice:r2/c2_show
execute if score #c2b sol.var = #c2t sol.var run function solstice:r2/solve_c2
