tag @s add sol.oob
execute if score #room sol.var matches 0 if entity @s[x=-60,y=80,z=-60,dx=120,dy=60,dz=120] run tag @s remove sol.oob
execute if score #room sol.var matches 1 if entity @s[x=940,y=80,z=-30,dx=120,dy=60,dz=60] run tag @s remove sol.oob
execute if score #room sol.var matches 2 if entity @s[x=1960,y=80,z=-40,dx=80,dy=80,dz=80] run tag @s remove sol.oob
execute if score #room sol.var matches 3 if entity @s[x=2950,y=80,z=-50,dx=100,dy=60,dz=100] run tag @s remove sol.oob
execute if score #room sol.var matches 4 if entity @s[x=3950,y=80,z=-50,dx=100,dy=60,dz=100] run tag @s remove sol.oob
execute if score #room sol.var matches 5 if entity @s[x=4940,y=60,z=-90,dx=120,dy=80,dz=150] run tag @s remove sol.oob
execute if score #room sol.var matches 6 if entity @s[x=5955,y=80,z=-45,dx=90,dy=70,dz=90] run tag @s remove sol.oob
execute if score #room sol.var matches 6 if entity @s[x=5955,y=80,z=155,dx=90,dy=70,dz=90] run tag @s remove sol.oob
execute if score #room sol.var matches 6 if entity @s[x=5955,y=80,z=355,dx=90,dy=70,dz=90] run tag @s remove sol.oob
execute if score #room sol.var matches 6 if entity @s[x=5955,y=80,z=555,dx=90,dy=70,dz=90] run tag @s remove sol.oob
execute if score #room sol.var matches 7 if entity @s[x=6950,y=80,z=-50,dx=100,dy=70,dz=100] run tag @s remove sol.oob
execute if score #room sol.var matches 8 if entity @s[x=-60,y=80,z=-60,dx=120,dy=60,dz=120] run tag @s remove sol.oob
execute if entity @s[tag=sol.oob] run function solstice:flow/oob
tag @s remove sol.oob
