execute as @e[type=item] if items entity @s contents lantern[custom_data~{sol:{lantern:1b}}] on origin run tag @s add sol.lgive
execute as @e[type=item] if items entity @s contents lantern[custom_data~{sol:{lantern:1b}}] run kill @s
function solstice:lantern/count
execute if score #lc sol.var matches 0 as @a[tag=sol.lgive] run function solstice:lantern/give
tag @a remove sol.lgive
function solstice:lantern/count
execute if score #lc sol.var matches 2.. as @a run clear @s lantern[custom_data~{sol:{lantern:1b}}]
execute if score #lc sol.var matches 2.. run scoreboard players set #lc sol.var 0
execute if score #lc sol.var matches 0 if entity @a run function solstice:lantern/regive
