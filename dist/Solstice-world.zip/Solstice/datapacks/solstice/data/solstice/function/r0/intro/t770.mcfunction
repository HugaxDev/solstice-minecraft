function solstice:r0/free
