scoreboard players add #endt sol.var 1
execute if score #endt sol.var matches 20 run function solstice:end/cine/t20
execute if score #endt sol.var matches 80 run function solstice:end/cine/t80
execute if score #endt sol.var matches 180 run function solstice:end/cine/t180
execute if score #endt sol.var matches 290 run function solstice:end/cine/t290
execute if score #endt sol.var matches 400 run function solstice:end/cine/t400
execute if score #endt sol.var matches 500 run function solstice:end/cine/t500
execute if score #endt sol.var matches 610 run function solstice:end/cine/t610
execute if score #endt sol.var matches 700 run function solstice:end/cine/t700
execute if score #endt sol.var matches 760 run function solstice:end/cine/t760
execute if score #endt sol.var matches 820 run function solstice:end/cine/t820
execute if score #endt sol.var matches 880 run function solstice:end/cine/t880
execute if score #endt sol.var matches 940 run function solstice:end/cine/t940
execute if score #endt sol.var matches 1040 run function solstice:end/cine/t1040
execute if score #endt sol.var matches 1100 run function solstice:end/credits
execute if score #endt sol.var matches 1300 run function solstice:end/epilogue
