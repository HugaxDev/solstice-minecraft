scoreboard players reset @s sol.room
scoreboard players set @s sol.dall 0
advancement revoke @s from solstice:root
advancement grant @s only solstice:root
clear @s
