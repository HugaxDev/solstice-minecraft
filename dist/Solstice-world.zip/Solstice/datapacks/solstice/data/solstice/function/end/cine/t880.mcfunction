function solstice:r7/seasons4
function solstice:r7/fireworks
