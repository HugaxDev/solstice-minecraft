function solstice:r2/c3_flip4
function solstice:r2/c3_flip1
function solstice:r2/c3_flip7
function solstice:r2/c3_flip3
function solstice:r2/c3_flip5
