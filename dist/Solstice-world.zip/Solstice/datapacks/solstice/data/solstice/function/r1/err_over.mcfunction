tellraw @a ["",{"text":"✖ La soupape saute ! Surpression : le train freine d’urgence et recule au dernier tronçon.","color":"red"}]
function solstice:r1/back
