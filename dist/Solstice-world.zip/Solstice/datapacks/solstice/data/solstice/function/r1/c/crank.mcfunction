execute if score @s sol.cool matches 1.. run return 0
scoreboard players set @s sol.cool 8
execute unless entity @s[tag=sol.ro3] run return run title @s actionbar {"text":"Ce n’est pas votre poste : c’est celui du Garde-barrière.","color":"red"}
execute unless score #ev_cross sol.var matches 1 run return run title @s actionbar {"text":"Aucune barrière en vue… pour l’instant.","color":"yellow"}
execute if score #bopen sol.var matches 1 run return run title @s actionbar {"text":"La barrière est déjà ouverte.","color":"green"}
scoreboard players add #crank sol.var 1
playsound minecraft:block.chain.step master @a ~ ~ ~ 1 0.7
execute if score #crank sol.var matches ..2 run title @s actionbar ["",{"text":"La manivelle tourne… ","color":"yellow"},{"score":{"name":"#crank","objective":"sol.var"},"color":"white"},{"text":" / 3","color":"gray"}]
execute if score #crank sol.var matches 3.. run function solstice:r1/barrier_open
