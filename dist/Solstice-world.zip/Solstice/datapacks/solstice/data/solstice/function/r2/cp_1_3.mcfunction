tp @s 1990.5 121 1.5 180 0
spawnpoint @s 1990 121 1
