execute if score #b1c sol.var = #b1n sol.var run return run function solstice:r2/solve_b1
playsound minecraft:block.note_block.bass master @a ~ ~ ~ 1 0.6
title @s actionbar {"text":"Le mécanisme ne bouge pas. Ce n’est pas le bon nombre.","color":"red"}
