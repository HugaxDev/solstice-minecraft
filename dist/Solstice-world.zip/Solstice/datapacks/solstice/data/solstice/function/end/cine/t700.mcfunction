title @a times 10 80 20
title @a subtitle {"text":"Printemps · Été · Automne · Hiver","color":"gray"}
title @a title {"text":"Les saisons se remettent en ordre","color":"green","bold":true}
function solstice:r7/seasons1
