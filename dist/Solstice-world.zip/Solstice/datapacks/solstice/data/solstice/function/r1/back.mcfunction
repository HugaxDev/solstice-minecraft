scoreboard players add #errors sol.var 1
scoreboard players operation #dist sol.var /= #cSEC sol.var
scoreboard players operation #dist sol.var *= #cSEC sol.var
function solstice:r1/ev_from_dist
function solstice:r1/reset_run
title @a times 5 40 10
title @a subtitle {"text":"Retour au début du tronçon.","color":"gray"}
title @a title {"text":"Le train recule…","color":"red","bold":true}
execute as @a at @s run playsound minecraft:block.anvil.land master @s ~ ~ ~ 0.5 0.6
effect give @a nausea 3 0 true
