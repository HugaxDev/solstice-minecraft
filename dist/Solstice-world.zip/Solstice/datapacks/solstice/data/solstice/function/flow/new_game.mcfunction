scoreboard players set #room sol.var 0
scoreboard players set #trans sol.var 0
scoreboard players set #started sol.var 0
scoreboard players set #ended sol.var 0
scoreboard players set #gtime sol.var 0
scoreboard players set #wipes sol.var 0
function solstice:story/reset
function solstice:lantern/reset
function solstice:flow/room_setup
function solstice:flow/start_room
execute as @a run function solstice:flow/new_game_player
