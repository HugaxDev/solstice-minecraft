scoreboard players set #c3_0 sol.var 1
setblock 2015 124 -1 sea_lantern
scoreboard players set #c3_1 sol.var 1
setblock 2015 124 0 sea_lantern
scoreboard players set #c3_2 sol.var 1
setblock 2015 124 1 sea_lantern
scoreboard players set #c3_3 sol.var 1
setblock 2015 123 -1 sea_lantern
scoreboard players set #c3_4 sol.var 1
setblock 2015 123 0 sea_lantern
scoreboard players set #c3_5 sol.var 1
setblock 2015 123 1 sea_lantern
scoreboard players set #c3_6 sol.var 1
setblock 2015 122 -1 sea_lantern
scoreboard players set #c3_7 sol.var 1
setblock 2015 122 0 sea_lantern
scoreboard players set #c3_8 sol.var 1
setblock 2015 122 1 sea_lantern
scoreboard players set #c3scr sol.var 1
execute store result score #rnd sol.var run random value 0..8
execute if score #rnd sol.var matches 0 run function solstice:r2/c3_scramble0
execute if score #rnd sol.var matches 1 run function solstice:r2/c3_scramble1
execute if score #rnd sol.var matches 2 run function solstice:r2/c3_scramble2
execute if score #rnd sol.var matches 3 run function solstice:r2/c3_scramble3
execute if score #rnd sol.var matches 4 run function solstice:r2/c3_scramble4
execute if score #rnd sol.var matches 5 run function solstice:r2/c3_scramble5
execute if score #rnd sol.var matches 6 run function solstice:r2/c3_scramble6
execute if score #rnd sol.var matches 7 run function solstice:r2/c3_scramble7
execute if score #rnd sol.var matches 8 run function solstice:r2/c3_scramble8
execute store result score #rnd sol.var run random value 0..8
execute if score #rnd sol.var matches 0 run function solstice:r2/c3_scramble0
execute if score #rnd sol.var matches 1 run function solstice:r2/c3_scramble1
execute if score #rnd sol.var matches 2 run function solstice:r2/c3_scramble2
execute if score #rnd sol.var matches 3 run function solstice:r2/c3_scramble3
execute if score #rnd sol.var matches 4 run function solstice:r2/c3_scramble4
execute if score #rnd sol.var matches 5 run function solstice:r2/c3_scramble5
execute if score #rnd sol.var matches 6 run function solstice:r2/c3_scramble6
execute if score #rnd sol.var matches 7 run function solstice:r2/c3_scramble7
execute if score #rnd sol.var matches 8 run function solstice:r2/c3_scramble8
execute store result score #rnd sol.var run random value 0..8
execute if score #rnd sol.var matches 0 run function solstice:r2/c3_scramble0
execute if score #rnd sol.var matches 1 run function solstice:r2/c3_scramble1
execute if score #rnd sol.var matches 2 run function solstice:r2/c3_scramble2
execute if score #rnd sol.var matches 3 run function solstice:r2/c3_scramble3
execute if score #rnd sol.var matches 4 run function solstice:r2/c3_scramble4
execute if score #rnd sol.var matches 5 run function solstice:r2/c3_scramble5
execute if score #rnd sol.var matches 6 run function solstice:r2/c3_scramble6
execute if score #rnd sol.var matches 7 run function solstice:r2/c3_scramble7
execute if score #rnd sol.var matches 8 run function solstice:r2/c3_scramble8
execute store result score #rnd sol.var run random value 0..8
execute if score #rnd sol.var matches 0 run function solstice:r2/c3_scramble0
execute if score #rnd sol.var matches 1 run function solstice:r2/c3_scramble1
execute if score #rnd sol.var matches 2 run function solstice:r2/c3_scramble2
execute if score #rnd sol.var matches 3 run function solstice:r2/c3_scramble3
execute if score #rnd sol.var matches 4 run function solstice:r2/c3_scramble4
execute if score #rnd sol.var matches 5 run function solstice:r2/c3_scramble5
execute if score #rnd sol.var matches 6 run function solstice:r2/c3_scramble6
execute if score #rnd sol.var matches 7 run function solstice:r2/c3_scramble7
execute if score #rnd sol.var matches 8 run function solstice:r2/c3_scramble8
execute store result score #rnd sol.var run random value 0..8
execute if score #rnd sol.var matches 0 run function solstice:r2/c3_scramble0
execute if score #rnd sol.var matches 1 run function solstice:r2/c3_scramble1
execute if score #rnd sol.var matches 2 run function solstice:r2/c3_scramble2
execute if score #rnd sol.var matches 3 run function solstice:r2/c3_scramble3
execute if score #rnd sol.var matches 4 run function solstice:r2/c3_scramble4
execute if score #rnd sol.var matches 5 run function solstice:r2/c3_scramble5
execute if score #rnd sol.var matches 6 run function solstice:r2/c3_scramble6
execute if score #rnd sol.var matches 7 run function solstice:r2/c3_scramble7
execute if score #rnd sol.var matches 8 run function solstice:r2/c3_scramble8
scoreboard players set #c3scr sol.var 0
execute if score #c3_0 sol.var matches 1 if score #c3_1 sol.var matches 1 if score #c3_2 sol.var matches 1 if score #c3_3 sol.var matches 1 if score #c3_4 sol.var matches 1 if score #c3_5 sol.var matches 1 if score #c3_6 sol.var matches 1 if score #c3_7 sol.var matches 1 if score #c3_8 sol.var matches 1 run function solstice:r2/c3_press4
