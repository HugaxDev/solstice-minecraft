fill 2012 121 -4 2012 123 -4 air
fill 2014 121 -4 2014 123 -4 air
fill 2013 121 -3 2013 123 -3 air
particle minecraft:electric_spark 2013.5 122 -2.5 0.6 0.8 0.6 0.1 30 force
playsound minecraft:block.iron_door.open master @a 2013 122 -3 2 0.7
