scoreboard players set #bit sol.var 1
scoreboard players operation #tmp sol.var = #m3cfg sol.var
scoreboard players operation #tmp sol.var /= #bit sol.var
scoreboard players operation #tmp sol.var %= #c2 sol.var
execute if score #tmp sol.var matches 0 run data merge entity @e[type=item_display,tag=sol.mir0,limit=1] {start_interpolation:0,interpolation_duration:5,transformation:{left_rotation:[0f,0.3827f,0f,0.9239f]}}
scoreboard players set #bit sol.var 1
scoreboard players operation #tmp sol.var = #m3cfg sol.var
scoreboard players operation #tmp sol.var /= #bit sol.var
scoreboard players operation #tmp sol.var %= #c2 sol.var
execute if score #tmp sol.var matches 1 run data merge entity @e[type=item_display,tag=sol.mir0,limit=1] {start_interpolation:0,interpolation_duration:5,transformation:{left_rotation:[0f,-0.3827f,0f,0.9239f]}}
scoreboard players set #bit sol.var 2
scoreboard players operation #tmp sol.var = #m3cfg sol.var
scoreboard players operation #tmp sol.var /= #bit sol.var
scoreboard players operation #tmp sol.var %= #c2 sol.var
execute if score #tmp sol.var matches 0 run data merge entity @e[type=item_display,tag=sol.mir1,limit=1] {start_interpolation:0,interpolation_duration:5,transformation:{left_rotation:[0f,0.3827f,0f,0.9239f]}}
scoreboard players set #bit sol.var 2
scoreboard players operation #tmp sol.var = #m3cfg sol.var
scoreboard players operation #tmp sol.var /= #bit sol.var
scoreboard players operation #tmp sol.var %= #c2 sol.var
execute if score #tmp sol.var matches 1 run data merge entity @e[type=item_display,tag=sol.mir1,limit=1] {start_interpolation:0,interpolation_duration:5,transformation:{left_rotation:[0f,-0.3827f,0f,0.9239f]}}
scoreboard players set #bit sol.var 4
scoreboard players operation #tmp sol.var = #m3cfg sol.var
scoreboard players operation #tmp sol.var /= #bit sol.var
scoreboard players operation #tmp sol.var %= #c2 sol.var
execute if score #tmp sol.var matches 0 run data merge entity @e[type=item_display,tag=sol.mir2,limit=1] {start_interpolation:0,interpolation_duration:5,transformation:{left_rotation:[0f,0.3827f,0f,0.9239f]}}
scoreboard players set #bit sol.var 4
scoreboard players operation #tmp sol.var = #m3cfg sol.var
scoreboard players operation #tmp sol.var /= #bit sol.var
scoreboard players operation #tmp sol.var %= #c2 sol.var
execute if score #tmp sol.var matches 1 run data merge entity @e[type=item_display,tag=sol.mir2,limit=1] {start_interpolation:0,interpolation_duration:5,transformation:{left_rotation:[0f,-0.3827f,0f,0.9239f]}}
scoreboard players set #bit sol.var 8
scoreboard players operation #tmp sol.var = #m3cfg sol.var
scoreboard players operation #tmp sol.var /= #bit sol.var
scoreboard players operation #tmp sol.var %= #c2 sol.var
execute if score #tmp sol.var matches 0 run data merge entity @e[type=item_display,tag=sol.mir3,limit=1] {start_interpolation:0,interpolation_duration:5,transformation:{left_rotation:[0f,0.3827f,0f,0.9239f]}}
scoreboard players set #bit sol.var 8
scoreboard players operation #tmp sol.var = #m3cfg sol.var
scoreboard players operation #tmp sol.var /= #bit sol.var
scoreboard players operation #tmp sol.var %= #c2 sol.var
execute if score #tmp sol.var matches 1 run data merge entity @e[type=item_display,tag=sol.mir3,limit=1] {start_interpolation:0,interpolation_duration:5,transformation:{left_rotation:[0f,-0.3827f,0f,0.9239f]}}
