tp @s 986.5 101 0.5 90 0
spawnpoint @s 986 101 0
