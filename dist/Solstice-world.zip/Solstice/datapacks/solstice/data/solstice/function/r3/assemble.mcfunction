scoreboard players set #asm sol.var 0
kill @e[type=!player,tag=sol.placed]
scoreboard players set #step sol.var 3
function solstice:hints/reset
function solstice:r3/obj
scoreboard players set #lantern sol.var 1
function solstice:lantern/regive
title @a times 10 70 20
title @a subtitle {"text":"Elle révèle ce que le temps a caché","color":"gray"}
title @a title {"text":"La Lanterne des Saisons","color":"gold","bold":true}
particle minecraft:end_rod 3000.5 102.5 0.5 1 1 1 0.1 120 force
execute as @a at @s run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 1 1.2
tellraw @a ["",{"text":"Maître Orel","color":"gold","bold":true},{"text":" » ","color":"dark_gray"},{"text":"Elle brille ! Promenez-la dans l’atelier : l’encre invisible, les passages cachés… Et je crois que j’avais laissé la porte de sortie fermée par un mot. Un mot écrit… à l’encre invisible. Oui. C’était très malin à l’époque.","color":"yellow"}]
tellraw @a ["",{"text":"Tenez la Lanterne en main près des murs. Épelez le mot caché en marchant sur les dalles-lettres, au sud de l’établi.","color":"gray","italic":true}]
