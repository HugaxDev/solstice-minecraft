tp @s 1990.5 101 1.5 180 0
spawnpoint @s 1990 101 1
