tag @s remove sol.secret
execute at @s run particle minecraft:end_rod ~ ~0.5 ~ 0.6 0.6 0.6 0.05 40
execute at @s run playsound minecraft:block.beacon.activate master @a[distance=..16] ~ ~ ~ 0.8 1.6
execute if entity @s[tag=sol.s_r3alcove] run function solstice:lantern/secret/r3alcove
