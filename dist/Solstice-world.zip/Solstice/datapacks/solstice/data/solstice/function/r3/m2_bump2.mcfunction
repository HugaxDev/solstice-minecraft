scoreboard players add #mel2 sol.var 1
execute if score #mel2 sol.var matches 5.. run scoreboard players set #mel2 sol.var 0
