execute if score #step sol.var matches 0 if score #m20 sol.var matches 0 run function solstice:r0/obj_wait
execute if score #step sol.var matches 0 if score #np sol.var >= #need sol.var run function solstice:r0/begin
execute if score #step sol.var matches 1 run function solstice:r0/intro_tick
execute if score #step sol.var matches 2 run function solstice:r0/board_check
function solstice:village/tick
