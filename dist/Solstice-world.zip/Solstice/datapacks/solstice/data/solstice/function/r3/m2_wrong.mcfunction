scoreboard players set #m2in sol.var 0
playsound minecraft:block.note_block.didgeridoo master @a ~ ~ ~ 1 0.6
title @a[tag=sol.ro2] actionbar {"text":"Fausse note… la boîte à musique rejoue la mélodie.","color":"red"}
scoreboard players set #m2play sol.var 1
scoreboard players set #m2pt sol.var -20
