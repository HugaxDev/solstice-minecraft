execute if score @s sol.cool matches 1.. run return 0
scoreboard players set @s sol.cool 6
execute unless entity @s[tag=sol.ro2] run return run title @s actionbar {"text":"Ce n’est pas votre poste : c’est celui du Chauffeur.","color":"red"}
execute unless items entity @s weapon.* coal[custom_data~{sol:{coal:1b}}] run return run title @s actionbar {"text":"La chaudière réclame du charbon (tender, juste derrière).","color":"gold"}
clear @s coal[custom_data~{sol:{coal:1b}}] 1
scoreboard players add #press sol.var 15
playsound minecraft:item.firecharge.use master @a ~ ~ ~ 0.8 0.8
particle minecraft:flame 984 101.8 0.5 0.2 0.2 0.2 0.02 15
