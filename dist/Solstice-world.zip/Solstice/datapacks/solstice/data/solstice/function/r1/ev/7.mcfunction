execute unless score #switch sol.var = #fside2 sol.var run return run function solstice:r1/err_fork
scoreboard players add #ev sol.var 1
scoreboard players set #signed sol.var 0
scoreboard players set #ev_cross sol.var 0
function solstice:r1/sign_free
tellraw @a ["",{"text":"✔ Bonne voie : ","color":"green"},{"text":"Pont-des-Brumes","color":"white"}]
execute as @a at @s run playsound minecraft:block.piston.contract master @s ~ ~ ~ 0.6 1.4
