spectate
gamemode adventure @s
function solstice:rooms/respawn
title @s actionbar {"text":"De retour dans la bataille !","color":"gold"}
