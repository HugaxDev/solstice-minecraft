scoreboard players set @s sol.leave 0
execute if score @s sol.down matches 1.. run scoreboard players set @s sol.down 1
execute unless entity @s[tag=sol.dn] run gamemode adventure @s
function solstice:lantern/on_rejoin
function solstice:story/sync_player
execute if score #trans sol.var matches 0 if score @s sol.room = #room sol.var run function solstice:rooms/enter
execute if score #room sol.var matches 1.. run tellraw @s ["",{"text":"Maître Orel","color":"gold","bold":true},{"text":" » ","color":"dark_gray"},{"text":"Vous revoilà ! Le groupe ne vous a pas attendu, mais presque.","color":"yellow"}]
