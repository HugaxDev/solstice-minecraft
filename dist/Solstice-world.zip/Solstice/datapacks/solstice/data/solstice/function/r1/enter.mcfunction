execute unless score @s sol.role matches 1..3 run function solstice:roles/fill_vacant
function solstice:r1/cp
function solstice:r1/kit
bossbar set solstice:train players @a
