scoreboard players set #step sol.var 1
scoreboard players set #started sol.var 1
scoreboard players set #gtime sol.var 0
scoreboard players set #r0t sol.var 0
bossbar set solstice:obj name ["",{"text":"◆ ","color":"gold"},{"text":"Écoutez Maître Orel","color":"white"}]
function solstice:hints/reset
