scoreboard players remove #asm sol.var 1
execute if score #asm sol.var matches 0 run function solstice:r3/asm_fail
