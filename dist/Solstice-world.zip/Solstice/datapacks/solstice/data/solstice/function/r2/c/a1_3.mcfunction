scoreboard players add #a1_3 sol.var 1
execute if score #a1_3 sol.var matches 4.. run scoreboard players set #a1_3 sol.var 0
playsound minecraft:block.chain.hit master @a ~ ~ ~ 1 1.2
function solstice:r2/a1_show
function solstice:r2/a1_check
