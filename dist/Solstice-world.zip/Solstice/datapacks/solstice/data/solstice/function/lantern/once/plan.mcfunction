function solstice:story/found_plan
