tp @s 2010.5 121 1.5 180 0
spawnpoint @s 2010 121 1
