kill @e[type=!player,tag=sol.mob]
scoreboard players set #trans sol.var 0
scoreboard players set #ended sol.var 0
scoreboard players set #room sol.var 2
scoreboard players set #started sol.var 1
execute as @a run function solstice:player/clear_role
function solstice:flow/room_setup
scoreboard players reset @a sol.room
function solstice:flow/start_room
execute as @a run function solstice:player/revive
tellraw @a ["",{"text":"[debug] Aller à la salle 2 : La Tour des Engrenages.","color":"red"}]
