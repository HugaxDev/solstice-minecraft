function solstice:r1/cp
function solstice:r1/kit
