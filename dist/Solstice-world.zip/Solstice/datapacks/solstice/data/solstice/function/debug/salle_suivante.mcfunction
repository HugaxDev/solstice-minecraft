tellraw @a ["",{"text":"[debug] Salle passée.","color":"red"}]
execute if score #room sol.var matches ..6 run function solstice:flow/complete
execute if score #room sol.var matches 7 run function solstice:end/start
