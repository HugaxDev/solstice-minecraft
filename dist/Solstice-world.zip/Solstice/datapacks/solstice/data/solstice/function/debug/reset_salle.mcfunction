kill @e[type=!player,tag=sol.mob]
scoreboard players set #trans sol.var 0
execute as @a run function solstice:player/clear_role
function solstice:flow/room_setup
scoreboard players reset @a sol.room
function solstice:flow/start_room
execute as @a run function solstice:player/revive
tellraw @a ["",{"text":"[debug] Salle en cours réinitialisée.","color":"red"}]
