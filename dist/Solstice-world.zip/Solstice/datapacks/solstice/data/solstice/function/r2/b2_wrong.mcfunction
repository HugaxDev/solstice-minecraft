playsound minecraft:block.note_block.bass master @a ~ ~ ~ 1 0.5
title @a actionbar {"text":"La serrure du Laiton recrache la combinaison.","color":"red"}
