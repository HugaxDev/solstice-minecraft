title @a times 10 70 20
title @a subtitle {"text":"Le Cœur du Calendrier bat de nouveau","color":"gray"}
title @a title {"text":"Le Verrou est brisé","color":"light_purple","bold":true}
