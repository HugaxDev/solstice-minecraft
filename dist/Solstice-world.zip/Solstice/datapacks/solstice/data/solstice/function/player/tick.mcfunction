execute store result score @s sol.y run data get entity @s Pos[1]
execute if score @s sol.leave matches 1.. run function solstice:player/rejoined
execute if score @s sol.deaths matches 1.. run function solstice:player/on_death
execute if score @s sol.down matches 1.. run function solstice:player/down_tick
execute if score #trans sol.var matches 0 if score #pstart sol.var matches 0 unless score @s sol.room = #room sol.var run function solstice:flow/enter
execute if score #trans sol.var matches 0 if score @s sol.room = #room sol.var run function solstice:flow/ptick
execute if score @s sol.cool matches 1.. run scoreboard players remove @s sol.cool 1
scoreboard players set @s sol.use 0
scoreboard players set @s sol.horn 0
