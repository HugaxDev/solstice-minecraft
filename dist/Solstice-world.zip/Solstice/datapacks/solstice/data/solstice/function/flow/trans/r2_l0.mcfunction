tellraw @a ["",{"text":"Au sommet de la tour, une porte ronde s’ouvre sur une odeur d’huile et de laiton.","color":"white","italic":true}]
execute as @a at @s run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.8 0.9
