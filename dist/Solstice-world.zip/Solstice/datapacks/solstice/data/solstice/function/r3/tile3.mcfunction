scoreboard players set @s sol.k 4
playsound minecraft:block.wood.step master @a ~ ~ ~ 1 1.2
execute if score #spell sol.var matches 1 run return run function solstice:r3/spell_ok
function solstice:r3/spell_bad
