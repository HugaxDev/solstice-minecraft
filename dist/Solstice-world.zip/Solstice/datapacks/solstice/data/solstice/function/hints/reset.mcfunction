scoreboard players set #ht sol.var 0
scoreboard players set #hk sol.var 0
