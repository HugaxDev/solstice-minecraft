function solstice:village/ptick
