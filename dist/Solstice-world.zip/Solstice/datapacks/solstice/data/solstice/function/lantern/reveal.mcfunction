execute as @a[gamemode=!spectator] if items entity @s weapon.* lantern[custom_data~{sol:{lantern:1b}}] at @s run function solstice:lantern/holder
execute as @e[type=text_display,tag=sol.ink,scores={sol.t=1..}] run function solstice:lantern/ink_tick
