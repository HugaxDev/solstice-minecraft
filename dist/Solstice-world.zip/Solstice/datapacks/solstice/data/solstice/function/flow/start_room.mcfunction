function solstice:flow/zone_loaded
execute if score #zl sol.var matches 0 run return run scoreboard players set #pstart sol.var 1
scoreboard players set #pstart sol.var 0
function solstice:rooms/start
