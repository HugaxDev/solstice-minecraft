advancement grant @a only solstice:challenge/fin_limier
tellraw @a ["",{"text":"★ Défi caché relevé : ","color":"aqua","bold":true},{"text":"Fin limier","color":"white"}]
execute as @a run function solstice:challenge/check_all
