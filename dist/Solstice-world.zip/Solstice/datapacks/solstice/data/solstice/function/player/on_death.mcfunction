scoreboard players set @s sol.deaths 0
scoreboard players add @s sol.dall 1
scoreboard players add #rdeaths sol.var 1
execute unless score @s sol.room = #room sol.var run return 0
execute if score #trans sol.var matches 1.. run return 0
tag @s add sol.dn
scoreboard players set @s sol.down 200
function solstice:rooms/respawn
execute if score #combat sol.var matches 1 run function solstice:player/ghost_start
execute if score #combat sol.var matches 0 run gamemode adventure @s
execute if score #combat sol.var matches 0 run title @s actionbar {"text":"Vous revoilà au dernier point de passage.","color":"gray"}
execute unless entity @a[tag=!sol.dn] run function solstice:flow/wipe
