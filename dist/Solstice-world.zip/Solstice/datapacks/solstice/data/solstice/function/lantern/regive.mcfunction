tag @a add sol.cand
scoreboard players set #tries sol.var 0
function solstice:roles/pick
execute as @a[tag=sol.pick] run function solstice:lantern/give
tellraw @a ["",{"text":"✦ La Lanterne des Saisons passe entre les mains de ","color":"gold"},{"selector":"@a[tag=sol.pick]","color":"white"},{"text":".","color":"gold"}]
tag @a remove sol.cand
tag @a remove sol.pick
