function solstice:r2/solve_b1
function solstice:r2/solve_b2
function solstice:r2/solve_b3
tellraw @a ["",{"text":"[debug] Puits du Laiton vacant : l’automate d’Orel résout ses mécanismes.","color":"red"}]
