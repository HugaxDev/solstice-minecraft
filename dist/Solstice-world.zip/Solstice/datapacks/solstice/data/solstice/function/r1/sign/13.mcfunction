data modify entity @e[type=text_display,tag=sol.r1sign,limit=1] text set value '["",{"text":"Fin de zone lente\\n","color":"green","bold":true},{"text":"On peut accélérer.","color":"white"}]'
execute as @a[tag=sol.ro1] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.6 1.2
