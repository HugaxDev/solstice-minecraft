execute if score #step sol.var matches 1 run bossbar set solstice:obj name ["",{"text":"◆ ","color":"gold"},{"text":"Chacun sa mission (portes au nord) : rapportez les trois pièces de la Lanterne","color":"white"}]
execute if score #step sol.var matches 2 run bossbar set solstice:obj name ["",{"text":"◆ ","color":"gold"},{"text":"Posez les trois pièces sur l’établi… en même temps !","color":"white"}]
execute if score #step sol.var matches 3 run bossbar set solstice:obj name ["",{"text":"◆ ","color":"gold"},{"text":"La Lanterne révèle ce qui était caché dans l’atelier","color":"white"}]
