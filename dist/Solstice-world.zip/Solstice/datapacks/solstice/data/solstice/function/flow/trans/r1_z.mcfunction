execute as @a run effect give @s blindness 3 0 true
title @a times 20 60 20
title @a subtitle {"text":"Salle 2","color":"gray"}
title @a title {"text":"La Tour des Engrenages","color":"gold","bold":true}
