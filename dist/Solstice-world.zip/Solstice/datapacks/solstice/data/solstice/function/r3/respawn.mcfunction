function solstice:r3/cp
