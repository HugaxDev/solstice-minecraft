execute if entity @s[x=2995,y=101,z=3,dx=1,dy=1,dz=1] unless score @s sol.k matches 1 run function solstice:r3/tile0
execute if entity @s[x=2998,y=101,z=3,dx=1,dy=1,dz=1] unless score @s sol.k matches 2 run function solstice:r3/tile1
execute if entity @s[x=3001,y=101,z=3,dx=1,dy=1,dz=1] unless score @s sol.k matches 3 run function solstice:r3/tile2
execute if entity @s[x=3004,y=101,z=3,dx=1,dy=1,dz=1] unless score @s sol.k matches 4 run function solstice:r3/tile3
execute if entity @s[x=2995,y=101,z=6,dx=1,dy=1,dz=1] unless score @s sol.k matches 5 run function solstice:r3/tile4
execute if entity @s[x=2998,y=101,z=6,dx=1,dy=1,dz=1] unless score @s sol.k matches 6 run function solstice:r3/tile5
execute if entity @s[x=3001,y=101,z=6,dx=1,dy=1,dz=1] unless score @s sol.k matches 7 run function solstice:r3/tile6
execute if entity @s[x=3004,y=101,z=6,dx=1,dy=1,dz=1] unless score @s sol.k matches 8 run function solstice:r3/tile7
execute if entity @s[x=2995,y=101,z=9,dx=1,dy=1,dz=1] unless score @s sol.k matches 9 run function solstice:r3/tile8
execute if entity @s[x=2998,y=101,z=9,dx=1,dy=1,dz=1] unless score @s sol.k matches 10 run function solstice:r3/tile9
execute if entity @s[x=3001,y=101,z=9,dx=1,dy=1,dz=1] unless score @s sol.k matches 11 run function solstice:r3/tile10
execute if entity @s[x=3004,y=101,z=9,dx=1,dy=1,dz=1] unless score @s sol.k matches 12 run function solstice:r3/tile11
execute unless entity @s[x=2995,y=101,z=3,dx=11,dy=1,dz=8] run scoreboard players set @s sol.k 0
