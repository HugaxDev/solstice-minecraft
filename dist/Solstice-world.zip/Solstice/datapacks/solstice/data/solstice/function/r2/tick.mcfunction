execute as @e[type=interaction,tag=sol.r2i] at @s if data entity @s interaction run function solstice:r2/clicked
execute as @e[type=interaction,tag=sol.r2i] at @s if data entity @s attack run function solstice:r2/clicked
execute if score #c1lock sol.var matches 1.. run scoreboard players remove #c1lock sol.var 1
execute if score #a3lock sol.var matches 1.. run scoreboard players remove #a3lock sol.var 1
execute store result score #atop sol.var if entity @a[x=1986,y=131,z=-4,dx=28,dy=7,dz=8,gamemode=!spectator]
execute if score #atop sol.var >= #np sol.var if score #atop sol.var >= #need sol.var run function solstice:r2/done
execute if score #atop sol.var matches 1.. if score #m20 sol.var matches 0 as @a[y=131,dy=8] run title @s actionbar ["",{"text":"Au sommet : ","color":"gold"},{"score":{"name":"#atop","objective":"sol.var"},"color":"white"},{"text":" / ","color":"gray"},{"score":{"name":"#np","objective":"sol.var"},"color":"white"}]
