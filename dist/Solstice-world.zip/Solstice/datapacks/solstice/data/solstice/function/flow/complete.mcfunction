execute if score #trans sol.var matches 1.. run return 0
execute if score #room sol.var matches 8.. run return 0
scoreboard players set #trans sol.var 1
execute if score #room sol.var matches 0 run advancement grant @a only solstice:room/r0
execute if score #room sol.var matches 1 run advancement grant @a only solstice:room/r1
execute if score #room sol.var matches 2 run advancement grant @a only solstice:room/r2
execute if score #room sol.var matches 3 run advancement grant @a only solstice:room/r3
execute if score #room sol.var matches 4 run advancement grant @a only solstice:room/r4
execute if score #room sol.var matches 5 run advancement grant @a only solstice:room/r5
execute if score #room sol.var matches 6 run advancement grant @a only solstice:room/r6
execute if score #room sol.var matches 7 run advancement grant @a only solstice:room/r7
function solstice:rooms/on_complete
kill @e[type=!player,tag=sol.mob]
execute as @a run function solstice:flow/trans_player
