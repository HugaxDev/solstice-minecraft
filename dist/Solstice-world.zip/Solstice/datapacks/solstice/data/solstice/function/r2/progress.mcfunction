scoreboard players set #lv sol.var 1
execute if score #lv sol.var matches 1 if score #s_a1 sol.var matches 1 if score #s_b1 sol.var matches 1 if score #s_c1 sol.var matches 1 run scoreboard players set #lv sol.var 2
execute if score #lv sol.var matches 2 if score #s_a2 sol.var matches 1 if score #s_b2 sol.var matches 1 if score #s_c2 sol.var matches 1 run scoreboard players set #lv sol.var 3
execute if score #lv sol.var matches 3 if score #s_a3 sol.var matches 1 if score #s_b3 sol.var matches 1 if score #s_c3 sol.var matches 1 run scoreboard players set #lv sol.var 4
execute unless score #lv sol.var = #step sol.var run function solstice:r2/new_step
