scoreboard players set #m2round sol.var 1
scoreboard players set #m2in sol.var 0
execute store result score #mel0 sol.var run random value 0..4
execute store result score #mel1 sol.var run random value 0..4
execute store result score #mel2 sol.var run random value 0..4
execute store result score #mel3 sol.var run random value 0..4
execute store result score #mel4 sol.var run random value 0..4
execute if score #mel1 sol.var = #mel0 sol.var run function solstice:r3/m2_bump1
execute if score #mel2 sol.var = #mel1 sol.var run function solstice:r3/m2_bump2
execute if score #mel3 sol.var = #mel2 sol.var run function solstice:r3/m2_bump3
execute if score #mel4 sol.var = #mel3 sol.var run function solstice:r3/m2_bump4
