execute unless score @s sol.role matches 1..3 run function solstice:roles/fill_vacant
function solstice:r3/cp
effect give @s night_vision infinite 0 true
