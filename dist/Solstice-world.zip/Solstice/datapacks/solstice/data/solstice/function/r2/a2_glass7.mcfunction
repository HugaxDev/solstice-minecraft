setblock 1990 113 5 brown_stained_glass
