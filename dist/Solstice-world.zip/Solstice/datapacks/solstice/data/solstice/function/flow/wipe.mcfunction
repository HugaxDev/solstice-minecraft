scoreboard players add #wipes sol.var 1
title @a times 10 60 20
title @a subtitle {"text":"La salle se réinitialise…","color":"gray"}
title @a title {"text":"Le groupe est tombé","color":"dark_red","bold":true}
execute as @a at @s run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 0.4 1.6
kill @e[type=!player,tag=sol.mob]
function solstice:rooms/wipe
execute as @a run function solstice:player/revive
function solstice:hints/reset
