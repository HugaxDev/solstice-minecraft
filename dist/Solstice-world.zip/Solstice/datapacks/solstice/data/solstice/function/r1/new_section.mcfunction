scoreboard players operation #step sol.var = #sec sol.var
function solstice:hints/reset
bossbar set solstice:obj name ["",{"text":"◆ ","color":"gold"},{"text":"L’Express : tronçon ","color":"white"},{"score":{"name":"#step","objective":"sol.var"},"color":"aqua"},{"text":" / 9","color":"gray"}]
