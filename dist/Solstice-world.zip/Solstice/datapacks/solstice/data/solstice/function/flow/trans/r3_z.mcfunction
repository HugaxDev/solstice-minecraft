execute as @a run effect give @s blindness 3 0 true
title @a times 20 60 20
title @a subtitle {"text":"Salle 4","color":"gray"}
title @a title {"text":"Le Siège du Sanctuaire","color":"red","bold":true}
