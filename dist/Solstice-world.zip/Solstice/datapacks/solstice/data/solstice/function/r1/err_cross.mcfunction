tellraw @a ["",{"text":"✖ BAM ! La barrière n’était pas ouverte. Le train recule au dernier tronçon.","color":"red"}]
function solstice:r1/back
