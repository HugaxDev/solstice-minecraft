scoreboard players set #press sol.var 45
scoreboard players set #speed sol.var 0
scoreboard players set #switch sol.var 0
scoreboard players set #bopen sol.var 0
scoreboard players set #crank sol.var 0
scoreboard players set #lim sol.var 0
scoreboard players set #signed sol.var 0
scoreboard players set #ev_cross sol.var 0
scoreboard players set #over sol.var 0
scoreboard players set #stall sol.var 0
scoreboard players set #pause sol.var 60
execute store result score #fside1 sol.var run random value 0..1
execute store result score #fside2 sol.var run random value 0..1
execute store result score #fside3 sol.var run random value 0..1
execute store result score #fside4 sol.var run random value 0..1
execute store result score #fside5 sol.var run random value 0..1
kill @e[type=!player,tag=sol.r1mob]
function solstice:r1/show_switch
function solstice:r1/sign_free
