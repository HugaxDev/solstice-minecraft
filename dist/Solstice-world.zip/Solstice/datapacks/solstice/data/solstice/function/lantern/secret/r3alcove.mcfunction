fill 2984 101 5 2985 103 6 air
tellraw @a ["",{"text":"✦ La Lanterne révèle un passage derrière les étagères !","color":"gold"}]
playsound minecraft:block.piston.contract master @a 2985 102 5 1 0.6
