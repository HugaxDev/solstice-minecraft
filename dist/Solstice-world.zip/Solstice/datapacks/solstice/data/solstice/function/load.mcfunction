scoreboard objectives add sol.var dummy {"text":"Variables"}
scoreboard objectives add sol.room dummy {"text":"Salle"}
scoreboard objectives add sol.joined dummy {"text":"Arrivé"}
scoreboard objectives add sol.role dummy {"text":"Rôle"}
scoreboard objectives add sol.deaths deathCount {"text":"Morts (à traiter)"}
scoreboard objectives add sol.dall dummy {"text":"Morts"}
scoreboard objectives add sol.leave minecraft.custom:minecraft.leave_game {"text":"Déconnexions"}
scoreboard objectives add sol.down dummy {"text":"À terre"}
scoreboard objectives add sol.cool dummy {"text":"Délai clic"}
scoreboard objectives add sol.rnd dummy {"text":"Tirage"}
scoreboard objectives add sol.rank dummy {"text":"Rang"}
scoreboard objectives add sol.use minecraft.used:minecraft.carrot_on_a_stick {"text":"Objet utilisé"}
scoreboard objectives add sol.horn minecraft.used:minecraft.goat_horn {"text":"Cor"}
scoreboard objectives add sol.t dummy {"text":"Minuteur"}
scoreboard objectives add sol.k dummy {"text":"Compteur"}
scoreboard objectives add sol.y dummy {"text":"Altitude"}
scoreboard objectives add sol.track dummy {"text":"Parcours"}
scoreboard objectives add sol.vote dummy {"text":"Vote"}
scoreboard objectives add sol.cp dummy {"text":"Checkpoint"}
scoreboard objectives add sol.test dummy {"text":"Tests"}
scoreboard objectives add sol.sneak minecraft.custom:minecraft.sneak_time {"text":"Accroupi"}
scoreboard objectives add sol.rroom dummy {"text":"Salle du rôle"}
gamerule doDaylightCycle false
gamerule doWeatherCycle false
gamerule doMobSpawning false
gamerule keepInventory true
gamerule fallDamage false
gamerule doImmediateRespawn true
gamerule announceAdvancements false
gamerule commandBlockOutput false
gamerule mobGriefing false
gamerule doFireTick false
gamerule spawnRadius 0
gamerule doInsomnia false
gamerule doPatrolSpawning false
gamerule doTraderSpawning false
gamerule disableRaids true
gamerule randomTickSpeed 0
gamerule doWardenSpawning false
gamerule spectatorsGenerateChunks false
gamerule logAdminCommands false
gamerule maxCommandChainLength 10000000
gamerule showDeathMessages false
gamerule doMobLoot false
gamerule doTileDrops false
gamerule doEntityDrops false
gamerule drowningDamage true
gamerule fireDamage true
gamerule naturalRegeneration true
gamerule sendCommandFeedback true
gamerule playersSleepingPercentage 101
gamerule spawnChunkRadius 0
weather clear 1000000
execute store result score #diff sol.var run difficulty
execute if score #diff sol.var matches 0 run function solstice:system/not_peaceful
scoreboard players set #c2 sol.var 2
scoreboard players set #c3 sol.var 3
scoreboard players set #c4 sol.var 4
scoreboard players set #c5 sol.var 5
scoreboard players set #c8 sol.var 8
scoreboard players set #c10 sol.var 10
scoreboard players set #c16 sol.var 16
scoreboard players set #c20 sol.var 20
scoreboard players set #c40 sol.var 40
scoreboard players set #c60 sol.var 60
scoreboard players set #c100 sol.var 100
scoreboard players set #c200 sol.var 200
scoreboard players set #c1000 sol.var 1000
scoreboard players set #c1200 sol.var 1200
scoreboard players set #c3600 sol.var 3600
scoreboard players set #c72000 sol.var 72000
execute unless score #room sol.var matches -2147483648..2147483647 run scoreboard players set #room sol.var 0
execute unless score #trans sol.var matches -2147483648..2147483647 run scoreboard players set #trans sol.var 0
execute unless score #need sol.var matches -2147483648..2147483647 run scoreboard players set #need sol.var 3
execute unless score #started sol.var matches -2147483648..2147483647 run scoreboard players set #started sol.var 0
execute unless score #gtime sol.var matches -2147483648..2147483647 run scoreboard players set #gtime sol.var 0
execute unless score #rt sol.var matches -2147483648..2147483647 run scoreboard players set #rt sol.var 0
execute unless score #ht sol.var matches -2147483648..2147483647 run scoreboard players set #ht sol.var 0
execute unless score #hk sol.var matches -2147483648..2147483647 run scoreboard players set #hk sol.var 0
execute unless score #step sol.var matches -2147483648..2147483647 run scoreboard players set #step sol.var 0
execute unless score #rdeaths sol.var matches -2147483648..2147483647 run scoreboard players set #rdeaths sol.var 0
execute unless score #np sol.var matches -2147483648..2147483647 run scoreboard players set #np sol.var 0
execute unless score #ended sol.var matches -2147483648..2147483647 run scoreboard players set #ended sol.var 0
execute unless score #wipes sol.var matches -2147483648..2147483647 run scoreboard players set #wipes sol.var 0
execute unless score #combat sol.var matches -2147483648..2147483647 run scoreboard players set #combat sol.var 0
execute unless score #win sol.var matches -2147483648..2147483647 run scoreboard players set #win sol.var 60
execute unless score #debug sol.var matches -2147483648..2147483647 run scoreboard players set #debug sol.var 0
execute unless score #pstart sol.var matches -2147483648..2147483647 run scoreboard players set #pstart sol.var 0
bossbar add solstice:obj "Solstice"
bossbar set solstice:obj style progress
bossbar set solstice:obj max 100
bossbar set solstice:obj value 100
bossbar set solstice:obj visible true
scoreboard players set #loaded sol.var 1
function solstice:flow/refresh_obj
function solstice:story/init
execute unless score #lantern sol.var matches 0.. run scoreboard players set #lantern sol.var 0
scoreboard objectives add sol.t_orel dummy
scoreboard objectives add sol.t_ysolde dummy
scoreboard objectives add sol.t_bram dummy
scoreboard objectives add sol.t_lise dummy
bossbar add solstice:train "L’Express du Solstice"
bossbar set solstice:train color blue
bossbar set solstice:train max 12600
bossbar set solstice:train visible false
scoreboard players set #cSEC sol.var 1400
scoreboard players set #c8 sol.var 8
scoreboard players set #cm1 sol.var -1
scoreboard objectives add sol.sea dummy
scoreboard objectives add sol.trv dummy
bossbar add solstice:r6hg "Sablier du Solstice"
bossbar set solstice:r6hg color yellow
bossbar set solstice:r6hg max 600
bossbar set solstice:r6hg visible false
