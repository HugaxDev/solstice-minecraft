fill 1998 111 -4 1998 113 -4 air
fill 1996 111 -4 1996 113 -4 air
fill 1997 111 -3 1997 113 -3 air
particle minecraft:electric_spark 1997.5 112 -2.5 0.6 0.8 0.6 0.1 30 force
playsound minecraft:block.iron_door.open master @a 1997 112 -3 2 0.7
