function solstice:story/found_graines
kill @e[type=!player,tag=sol.r2seed]
tellraw @s ["",{"text":"Coincé dans un engrenage : un sachet de graines déchiré.","color":"gray","italic":true}]
