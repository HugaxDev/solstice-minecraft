tellraw @a ["",{"text":"Maître Orel","color":"gold","bold":true},{"text":" » ","color":"dark_gray"},{"text":"…C’est vrai. Tout est vrai. Je voulais un jour sans fin, avec vous tous dedans. Un jour sans printemps, aussi. J’avais oublié ce détail.","color":"yellow"}]
execute as @a at @s run playsound minecraft:block.bell.resonate master @s ~ ~ ~ 0.6 0.6
