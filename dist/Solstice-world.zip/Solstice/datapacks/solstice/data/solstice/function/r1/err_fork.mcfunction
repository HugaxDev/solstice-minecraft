tellraw @a ["",{"text":"✖ Mauvaise voie ! Le train freine et recule jusqu’au dernier aiguillage.","color":"red"}]
function solstice:r1/back
