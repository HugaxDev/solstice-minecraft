execute if score @s sol.cool matches 1.. run return 0
scoreboard players set @s sol.cool 10
execute unless entity @s[tag=sol.ro2] run return run title @s actionbar {"text":"Ce n’est pas votre poste : c’est celui du Chauffeur.","color":"red"}
execute if items entity @s container.* coal[custom_data~{sol:{coal:1b}}] run return run title @s actionbar {"text":"Vous avez déjà une pelletée : à la chaudière !","color":"gold"}
give @s minecraft:coal[custom_name='{"text":"Pelletée de charbon","color":"dark_gray","italic":false}',lore=['{"text":"Pour la chaudière.","color":"gray","italic":true}'],custom_data={sol:{coal:1b}},max_stack_size=4]
playsound minecraft:block.gravel.break master @a ~ ~ ~ 1 0.8
title @s actionbar {"text":"Une pelletée de charbon. Vite, à la chaudière !","color":"gold"}
