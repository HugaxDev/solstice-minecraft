setblock 1990 113 5 white_stained_glass
