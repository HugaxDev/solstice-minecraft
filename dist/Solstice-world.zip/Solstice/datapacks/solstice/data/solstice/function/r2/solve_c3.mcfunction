execute if score #s_c3 sol.var matches 1 run return 0
scoreboard players set #s_c3 sol.var 1
function solstice:r2/open_a3
tellraw @a ["",{"text":"⚙ ","color":"gold"},{"text":"Puits du Fer","color":"gray"},{"text":" : mécanisme résolu → la grille du ","color":"gray"},{"text":"puits du Cuivre","color":"gold"},{"text":" (niveau 3) s’ouvre !","color":"gray"}]
execute as @a at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.8 1.4
function solstice:r2/progress
