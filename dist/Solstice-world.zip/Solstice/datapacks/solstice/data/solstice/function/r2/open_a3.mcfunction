fill 1992 121 -4 1992 123 -4 air
fill 1994 121 -4 1994 123 -4 air
fill 1993 121 -3 1993 123 -3 air
particle minecraft:electric_spark 1993.5 122 -2.5 0.6 0.8 0.6 0.1 30 force
playsound minecraft:block.iron_door.open master @a 1993 122 -3 2 0.7
