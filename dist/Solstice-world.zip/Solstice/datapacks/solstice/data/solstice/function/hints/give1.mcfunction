scoreboard players set #hk sol.var 1
scoreboard players add #hints sol.var 1
tellraw @a ["",{"text":"✦ Indice (1/2)","color":"aqua","bold":true},{"text":" — vous bloquez depuis un moment…","color":"gray","italic":true}]
function solstice:rooms/hint
execute as @a at @s run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 1 1.5
