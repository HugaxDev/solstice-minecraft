execute if score #b2e sol.var = #b2code sol.var run function solstice:r2/solve_b2
execute unless score #b2e sol.var = #b2code sol.var run function solstice:r2/b2_wrong
scoreboard players set #b2e sol.var 0
scoreboard players set #b2n sol.var 0
function solstice:r2/b2_show
