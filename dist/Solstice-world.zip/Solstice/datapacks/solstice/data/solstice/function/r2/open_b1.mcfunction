fill 2002 101 -4 2002 103 -4 air
fill 2004 101 -4 2004 103 -4 air
fill 2003 101 -3 2003 103 -3 air
particle minecraft:electric_spark 2003.5 102 -2.5 0.6 0.8 0.6 0.1 30 force
playsound minecraft:block.iron_door.open master @a 2003 102 -3 2 0.7
