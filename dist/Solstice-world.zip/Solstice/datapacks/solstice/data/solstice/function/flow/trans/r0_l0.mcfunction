tellraw @a ["",{"text":"L’Express du Solstice siffle dans la brume…","color":"white","italic":true}]
execute as @a at @s run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.8 0.9
