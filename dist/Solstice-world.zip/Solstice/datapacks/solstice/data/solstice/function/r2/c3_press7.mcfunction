function solstice:r2/c3_flip7
function solstice:r2/c3_flip4
function solstice:r2/c3_flip6
function solstice:r2/c3_flip8
function solstice:r2/c3_check
