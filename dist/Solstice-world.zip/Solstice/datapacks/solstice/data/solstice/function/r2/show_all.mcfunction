function solstice:r2/a1_show
function solstice:r2/b1_show
function solstice:r2/mk_show
