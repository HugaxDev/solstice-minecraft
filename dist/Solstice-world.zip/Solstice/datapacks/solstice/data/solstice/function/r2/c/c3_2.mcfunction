function solstice:r2/c3_press2
playsound minecraft:block.lever.click master @a ~ ~ ~ 1 1.3
