scoreboard players add #mel4 sol.var 1
execute if score #mel4 sol.var matches 5.. run scoreboard players set #mel4 sol.var 0
