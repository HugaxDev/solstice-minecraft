function solstice:r2/setup
scoreboard players set #step sol.var 1
function solstice:r2/obj
function solstice:roles/draw
function solstice:r2/announce
execute as @a run scoreboard players set @s sol.cp 1
execute if score #vac1 sol.var matches 1 run function solstice:r2/auto1
execute if score #vac2 sol.var matches 1 run function solstice:r2/auto2
execute if score #vac3 sol.var matches 1 run function solstice:r2/auto3
tellraw @a ["",{"text":"Maître Orel","color":"gold","bold":true},{"text":" » ","color":"dark_gray"},{"text":"La Tour des Engrenages ! Trois puits, trois grimpeurs. Chaque mécanisme ouvre la grille d’un voisin. Regardez à travers les vitres et parlez-vous : les engrenages adorent la conversation.","color":"yellow"}]
