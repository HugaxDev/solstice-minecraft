scoreboard players set #need sol.var 2
scoreboard players set #debug sol.var 1
scoreboard players set #win sol.var 1200
function solstice:roles/revac
tellraw @a ["",{"text":"[debug] Partie réglée pour 2 joueur(s).","color":"red"},{"text":" Rôles vacants : joués par tout le monde ou par l’automate d’Orel.","color":"gray"}]
