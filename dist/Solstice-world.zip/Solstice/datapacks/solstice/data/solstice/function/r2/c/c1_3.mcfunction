execute if score #c1lock sol.var matches 1.. run return run title @s actionbar {"text":"Les gabarits sont bloqués… patientez.","color":"gray"}
execute if score #c1t sol.var matches 3 run return run function solstice:r2/solve_c1
scoreboard players set #c1lock sol.var 100
playsound minecraft:block.anvil.land master @a ~ ~ ~ 0.5 1.4
title @s actionbar {"text":"Ce gabarit ne correspond pas. Les gabarits se bloquent 5 secondes.","color":"red"}
