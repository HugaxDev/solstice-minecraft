data modify entity @e[type=text_display,tag=sol.r1sign,limit=1] text set value '["",{"text":"⚠ PASSAGE À NIVEAU\\n","color":"red","bold":true},{"text":"La barrière est fermée !","color":"white"}]'
execute as @a[tag=sol.ro1] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.6 1.2
execute as @a at @s run playsound minecraft:block.bell.use master @s ~ ~ ~ 0.5 1.6
