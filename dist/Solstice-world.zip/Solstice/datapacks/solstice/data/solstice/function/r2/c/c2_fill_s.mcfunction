scoreboard players set #c2s sol.var 3
playsound minecraft:item.bucket.fill master @a ~ ~ ~ 0.8 1
function solstice:r2/c2_show
execute if score #c2b sol.var = #c2t sol.var run function solstice:r2/solve_c2
