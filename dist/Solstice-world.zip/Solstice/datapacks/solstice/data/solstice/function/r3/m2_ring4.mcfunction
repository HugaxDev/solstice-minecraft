playsound minecraft:block.note_block.bell master @a 3004 102 45 2 1.4
particle minecraft:note 3004.5 103.2 45.5 0.2 0.2 0.2 1 6 force
particle minecraft:end_rod 3004.5 102.5 45.5 0.3 0.3 0.3 0.02 10 force
