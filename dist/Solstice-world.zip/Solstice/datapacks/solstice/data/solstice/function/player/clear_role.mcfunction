scoreboard players set @s sol.role 0
scoreboard players reset @s sol.rroom
tag @s remove sol.ro1
tag @s remove sol.ro2
tag @s remove sol.ro3
