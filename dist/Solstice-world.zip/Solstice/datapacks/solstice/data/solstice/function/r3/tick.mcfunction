execute as @e[type=interaction,tag=sol.r3i] at @s if data entity @s interaction run function solstice:r3/clicked
execute as @e[type=interaction,tag=sol.r3i] at @s if data entity @s attack run function solstice:r3/clicked
execute if score #asm sol.var matches 1.. run function solstice:r3/asm_tick
execute if score #m2play sol.var matches 1 run function solstice:r3/m2_play_tick
execute if score #m4 sol.var matches 0 run function solstice:r3/beam
