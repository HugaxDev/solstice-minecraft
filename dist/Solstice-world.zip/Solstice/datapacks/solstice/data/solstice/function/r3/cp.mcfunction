tp @s 3000.5 101 5.5 180 0
spawnpoint @s 3000 101 5
