execute as @e[type=text_display,tag=sol.ink,distance=..5] run scoreboard players set @s sol.t 3
execute as @e[type=marker,tag=sol.secret,distance=..3] run function solstice:lantern/secret_found
particle minecraft:end_rod ~ ~1.2 ~ 0.4 0.4 0.4 0.01 2
