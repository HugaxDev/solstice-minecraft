scoreboard players set @s sol.k 5
playsound minecraft:block.wood.step master @a ~ ~ ~ 1 1.2
function solstice:r3/spell_bad
