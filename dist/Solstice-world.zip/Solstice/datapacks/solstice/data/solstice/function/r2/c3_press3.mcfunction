function solstice:r2/c3_flip3
function solstice:r2/c3_flip0
function solstice:r2/c3_flip6
function solstice:r2/c3_flip4
function solstice:r2/c3_check
