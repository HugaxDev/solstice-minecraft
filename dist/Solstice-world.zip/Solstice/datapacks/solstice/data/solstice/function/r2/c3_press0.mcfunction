function solstice:r2/c3_flip0
function solstice:r2/c3_flip3
function solstice:r2/c3_flip1
function solstice:r2/c3_check
