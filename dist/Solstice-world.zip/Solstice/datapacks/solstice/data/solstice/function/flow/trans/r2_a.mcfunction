title @a times 10 50 10
title @a subtitle {"text":"La Tour des Engrenages","color":"gray"}
title @a title {"text":"Salle terminée","color":"gold","bold":true}
