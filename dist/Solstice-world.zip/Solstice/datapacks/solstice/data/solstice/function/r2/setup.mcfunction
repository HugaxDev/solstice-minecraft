kill @e[type=!player,tag=sol.r2d]
scoreboard players set #r2t sol.var 0
scoreboard players set #s_a1 sol.var 0
scoreboard players set #s_b1 sol.var 0
scoreboard players set #s_c1 sol.var 0
scoreboard players set #s_a2 sol.var 0
scoreboard players set #s_b2 sol.var 0
scoreboard players set #s_c2 sol.var 0
scoreboard players set #s_a3 sol.var 0
scoreboard players set #s_b3 sol.var 0
scoreboard players set #s_c3 sol.var 0
function solstice:r2/close_a1
function solstice:r2/close_a2
function solstice:r2/close_a3
function solstice:r2/close_b1
function solstice:r2/close_b2
function solstice:r2/close_b3
function solstice:r2/close_c1
function solstice:r2/close_c2
function solstice:r2/close_c3
summon interaction 1988.5 101.3 4.3 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_a1_1"],width:0.9f,height:0.9f,response:1b}
summon text_display 1988.5 102.7 4.9 {Tags:["sol","sol.r2","sol.r2d","sol.a1d1"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"↑","color":"gold","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.6f,1.6f,1.6f]}}
scoreboard players set #a1_1 sol.var 0
execute store result score #a1t_1 sol.var run random value 1..3
summon interaction 1990.5 101.3 4.3 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_a1_2"],width:0.9f,height:0.9f,response:1b}
summon text_display 1990.5 102.7 4.9 {Tags:["sol","sol.r2","sol.r2d","sol.a1d2"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"↑","color":"gold","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.6f,1.6f,1.6f]}}
scoreboard players set #a1_2 sol.var 0
execute store result score #a1t_2 sol.var run random value 1..3
summon interaction 1992.5 101.3 4.3 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_a1_3"],width:0.9f,height:0.9f,response:1b}
summon text_display 1992.5 102.7 4.9 {Tags:["sol","sol.r2","sol.r2d","sol.a1d3"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"↑","color":"gold","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.6f,1.6f,1.6f]}}
scoreboard players set #a1_3 sol.var 0
execute store result score #a1t_3 sol.var run random value 1..3
summon text_display 1990.5 104.2 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"Cadrans du Cuivre","color":"gold","bold":true},{"text":"\\nClic : tourner l’aiguille","color":"gray"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
summon text_display 1996.05 105.0 3.0 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[-90f,0f],billboard:"fixed",text:'["",{"text":"Les aiguilles du puits voisin\\ndoivent montrer :","color":"yellow"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
summon text_display 1996.05 103.6 2.1 {Tags:["sol","sol.r2","sol.r2d","sol.a1t1"],Rotation:[-90f,0f],billboard:"fixed",text:'["",{"text":"?","color":"gold","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.4f,1.4f,1.4f]}}
summon text_display 1996.05 103.6 3.0 {Tags:["sol","sol.r2","sol.r2d","sol.a1t2"],Rotation:[-90f,0f],billboard:"fixed",text:'["",{"text":"?","color":"gold","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.4f,1.4f,1.4f]}}
summon text_display 1996.05 103.6 3.9 {Tags:["sol","sol.r2","sol.r2d","sol.a1t3"],Rotation:[-90f,0f],billboard:"fixed",text:'["",{"text":"?","color":"gold","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.4f,1.4f,1.4f]}}
function solstice:r2/b1_stars
scoreboard players set #b1c sol.var 0
summon interaction 1998.5 101.3 4.3 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_b1_minus"],width:0.9f,height:0.9f,response:1b}
summon interaction 2002.5 101.3 4.3 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_b1_plus"],width:0.9f,height:0.9f,response:1b}
summon interaction 2000.5 101.0 3.4 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_b1_ok"],width:1.2f,height:1.0f,response:1b}
summon text_display 1998.5 102.4 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"−","color":"yellow","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.6f,1.6f,1.6f]}}
summon text_display 2002.5 102.4 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"+","color":"yellow","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.6f,1.6f,1.6f]}}
summon text_display 2000.5 102.6 4.9 {Tags:["sol","sol.r2","sol.r2d","sol.b1v"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"0","color":"white","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.8f,1.8f,1.8f]}}
summon text_display 2000.5 102.1 3.4 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"Valider","color":"green"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]}}
summon text_display 2000.5 104.3 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"Combien d’étoiles ✹ brillent\\ndans le puits du Fer, à ce niveau ?","color":"yellow"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
summon interaction 2007.5 102.0 4.3 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_c1_1"],width:1.2f,height:1.2f,response:1b}
summon text_display 2007.5 105.3 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"I","color":"white"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
summon interaction 2010.5 102.0 4.3 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_c1_2"],width:1.2f,height:1.2f,response:1b}
summon text_display 2010.5 105.3 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"II","color":"white"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
summon interaction 2013.5 102.0 4.3 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_c1_3"],width:1.2f,height:1.2f,response:1b}
summon text_display 2013.5 105.3 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"III","color":"white"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
summon interaction 2014.3 102.0 0.5 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_c1_4"],width:1.2f,height:1.2f,response:1b}
summon text_display 2014.95 105.3 0.5 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[90f,0f],billboard:"fixed",text:'["",{"text":"IV","color":"white"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
summon interaction 2014.3 102.0 3.5 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_c1_5"],width:1.2f,height:1.2f,response:1b}
summon text_display 2014.95 105.3 3.5 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[90f,0f],billboard:"fixed",text:'["",{"text":"V","color":"white"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
summon interaction 2007.5 102.0 -3.7 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_c1_6"],width:1.2f,height:1.2f,response:1b}
summon text_display 2007.5 105.3 -3.95 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[0f,0f],billboard:"fixed",text:'["",{"text":"VI","color":"white"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
summon text_display 2010.5 106.5 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"Gabarits de fer\\n","color":"gray","bold":true},{"text":"Clic : choisir celui qui correspond au modèle","color":"gray"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
execute store result score #c1t sol.var run random value 1..6
execute if score #c1t sol.var matches 1 run function solstice:r2/c1_show1
execute if score #c1t sol.var matches 2 run function solstice:r2/c1_show2
execute if score #c1t sol.var matches 3 run function solstice:r2/c1_show3
execute if score #c1t sol.var matches 4 run function solstice:r2/c1_show4
execute if score #c1t sol.var matches 5 run function solstice:r2/c1_show5
execute if score #c1t sol.var matches 6 run function solstice:r2/c1_show6
summon text_display 1986.05 105.6 0.5 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[-90f,0f],billboard:"fixed",text:'["",{"text":"Modèle du gabarit (puits du Fer)","color":"gold"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
scoreboard players set #c1lock sol.var 0
summon interaction 1988.5 110.95 3.5 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_a2_1"],width:1.3f,height:1.2f,response:1b}
summon text_display 1988.5 112.4 3.5 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"Rouge","color":"red"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
summon interaction 1990.5 110.95 3.5 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_a2_2"],width:1.3f,height:1.2f,response:1b}
summon text_display 1990.5 112.4 3.5 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"Jaune","color":"yellow"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
summon interaction 1992.5 110.95 3.5 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_a2_3"],width:1.3f,height:1.2f,response:1b}
summon text_display 1992.5 112.4 3.5 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"Bleu","color":"blue"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
scoreboard players set #a2m sol.var 0
scoreboard players set #a2s sol.var 0
execute store result score #a2p sol.var run random value 0..5
setblock 1990 113 5 white_stained_glass
summon text_display 1990.5 114.4 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"Vitrail du Cuivre\\n","color":"gold","bold":true},{"text":"Clic sur une cuve : ajouter/retirer sa couleur","color":"gray"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
summon text_display 1996.05 115.4 -2.5 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[-90f,0f],billboard:"fixed",text:'["",{"text":"Le vitrail voisin doit prendre\\nces couleurs, dans l’ordre :","color":"yellow"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
function solstice:r2/a2_targets
summon text_display 1996.05 113.50000000000001 -3.3 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[-90f,0f],billboard:"fixed",text:'["",{"text":"1.","color":"white"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
summon text_display 1996.05 112.20000000000002 -3.3 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[-90f,0f],billboard:"fixed",text:'["",{"text":"2.","color":"white"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
execute store result score #b2seq sol.var run random value 0..5
execute store result score #b2leg sol.var run random value 0..5
scoreboard players set #b2n sol.var 0
scoreboard players set #b2e sol.var 0
function solstice:r2/b2_setup
summon interaction 1997.5 111.3 4.3 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_b2_1"],width:0.9f,height:0.9f,response:1b}
summon text_display 1997.5 112.5 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"1","color":"yellow","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.4f,1.4f,1.4f]}}
summon interaction 1999.5 111.3 4.3 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_b2_2"],width:0.9f,height:0.9f,response:1b}
summon text_display 1999.5 112.5 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"2","color":"yellow","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.4f,1.4f,1.4f]}}
summon interaction 2001.5 111.3 4.3 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_b2_3"],width:0.9f,height:0.9f,response:1b}
summon text_display 2001.5 112.5 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"3","color":"yellow","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.4f,1.4f,1.4f]}}
summon interaction 2003.5 111.3 4.3 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_b2_4"],width:0.9f,height:0.9f,response:1b}
summon text_display 2003.5 112.5 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"4","color":"yellow","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.4f,1.4f,1.4f]}}
summon text_display 2000.5 113.6 4.9 {Tags:["sol","sol.r2","sol.r2d","sol.b2v"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"_ _ _ _","color":"white","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.2f,1.2f,1.2f]}}
summon text_display 2000.5 114.8 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"Serrure du Laiton : quatre chiffres","color":"yellow"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
scoreboard players set #c2b sol.var 0
scoreboard players set #c2s sol.var 0
execute store result score #rnd sol.var run random value 0..1
execute if score #rnd sol.var matches 0 run scoreboard players set #c2t sol.var 4
execute if score #rnd sol.var matches 1 run scoreboard players set #c2t sol.var 1
summon interaction 2007.5 111.3 4.3 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_c2_fill_b"],width:0.9f,height:0.9f,response:1b}
summon text_display 2007.5 112.3 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"Remplir la grande","color":"aqua"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.45f,0.45f,0.45f]}}
summon interaction 2009.5 111.3 4.3 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_c2_fill_s"],width:0.9f,height:0.9f,response:1b}
summon text_display 2009.5 112.3 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"Remplir la petite","color":"aqua"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.45f,0.45f,0.45f]}}
summon interaction 2011.5 111.3 4.3 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_c2_empty_b"],width:0.9f,height:0.9f,response:1b}
summon text_display 2011.5 112.3 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"Vider la grande","color":"aqua"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.45f,0.45f,0.45f]}}
summon interaction 2013.5 111.3 4.3 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_c2_empty_s"],width:0.9f,height:0.9f,response:1b}
summon text_display 2013.5 112.3 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"Vider la petite","color":"aqua"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.45f,0.45f,0.45f]}}
summon interaction 2014.3 111.3 0.5 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_c2_b2s"],width:0.9f,height:0.9f,response:1b}
summon text_display 2014.95 112.3 0.5 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[90f,0f],billboard:"fixed",text:'["",{"text":"Grande → petite","color":"aqua"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.45f,0.45f,0.45f]}}
summon interaction 2014.3 111.3 2.5 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_c2_s2b"],width:0.9f,height:0.9f,response:1b}
summon text_display 2014.95 112.3 2.5 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[90f,0f],billboard:"fixed",text:'["",{"text":"Petite → grande","color":"aqua"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.45f,0.45f,0.45f]}}
summon text_display 2010.5 113.6 4.9 {Tags:["sol","sol.r2","sol.r2d","sol.c2vb"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"Grande cuve : 0 / 5 L","color":"white"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]}}
summon text_display 2010.5 113.0 4.9 {Tags:["sol","sol.r2","sol.r2d","sol.c2vs"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"Petite cuve : 0 / 3 L","color":"white"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]}}
summon text_display 2010.5 114.6 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"Cuves du Fer","color":"gray","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
function solstice:r2/c2_target
summon interaction 2011.5 111.0 -3.2 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_seeds"],width:0.8f,height:0.6f,response:1b}
execute unless score #clue_graines sol.var matches 1 run summon item_display 2011.5 111.2 -3.2 {Tags:["sol","sol.r2","sol.r2d","sol.r2seed"],item:{id:"minecraft:sunflower",count:1},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]}}
setblock 1988 122 4 lever[face=wall,facing=north,powered=false]
summon text_display 1988.5 123.1 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"L1","color":"gold","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]}}
setblock 1990 122 4 lever[face=wall,facing=north,powered=false]
summon text_display 1990.5 123.1 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"L2","color":"gold","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]}}
setblock 1992 122 4 lever[face=wall,facing=north,powered=false]
summon text_display 1992.5 123.1 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"L3","color":"gold","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]}}
summon interaction 1990.5 120.95 2.5 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_a3_ok"],width:1.3f,height:1.3f,response:1b}
summon text_display 1990.5 122.3 2.5 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"Valider\\n","color":"green"},{"text":"(erreur : 20 s de blocage)","color":"gray"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.45f,0.45f,0.45f]}}
setblock 1990 125 5 black_concrete
summon text_display 1990.5 126.3 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"Lampe du Cuivre","color":"gold"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
execute store result score #a3c sol.var run random value 0..3
scoreboard players set #a3lock sol.var 0
function solstice:r2/a3_diagram
execute store result score #b3m sol.var run random value 0..2
scoreboard players set #mx sol.var 0
scoreboard players set #my sol.var 3
summon interaction 1997.5 121.3 4.3 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_b3_n"],width:0.9f,height:0.9f,response:1b}
summon text_display 1997.5 122.4 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"↑ Nord","color":"yellow","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
summon interaction 1999.5 121.3 4.3 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_b3_s"],width:0.9f,height:0.9f,response:1b}
summon text_display 1999.5 122.4 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"↓ Sud","color":"yellow","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
summon interaction 2001.5 121.3 4.3 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_b3_w"],width:0.9f,height:0.9f,response:1b}
summon text_display 2001.5 122.4 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"← Ouest","color":"yellow","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
summon interaction 2003.5 121.3 4.3 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_b3_e"],width:0.9f,height:0.9f,response:1b}
summon text_display 2003.5 122.4 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"→ Est","color":"yellow","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
summon text_display 2000.5 124.4 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"Guidez le palet d’or jusqu’à la dalle d’émeraude.\\n","color":"yellow"},{"text":"Les murs sont invisibles… d’ici.","color":"gray"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
summon block_display 1997.1 121 -2.9 {Tags:["sol","sol.r2","sol.r2d","sol.mk"],teleport_duration:4,block_state:{Name:"minecraft:gold_block"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.4f,0.8f]}}
execute if score #b3m sol.var matches 0 run function solstice:r2/b3_mural0
execute if score #b3m sol.var matches 1 run function solstice:r2/b3_mural1
execute if score #b3m sol.var matches 2 run function solstice:r2/b3_mural2
summon block_display 2013.1 122.1 4.6 {Tags:["sol","sol.r2","sol.r2d","sol.mk2"],teleport_duration:4,block_state:{Name:"minecraft:gold_block"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.3f]}}
summon text_display 2010.5 129.6 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"N","color":"white","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]}}
summon text_display 2014.75 125.2 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"E","color":"white","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]}}
summon text_display 2006.2 125.2 4.9 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"O","color":"white","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]}}
summon interaction 2014.4 124.05 -0.5 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_c3_0"],width:0.9f,height:0.9f,response:1b}
summon interaction 2014.4 124.05 0.5 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_c3_1"],width:0.9f,height:0.9f,response:1b}
summon interaction 2014.4 124.05 1.5 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_c3_2"],width:0.9f,height:0.9f,response:1b}
summon interaction 2014.4 123.05 -0.5 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_c3_3"],width:0.9f,height:0.9f,response:1b}
summon interaction 2014.4 123.05 0.5 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_c3_4"],width:0.9f,height:0.9f,response:1b}
summon interaction 2014.4 123.05 1.5 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_c3_5"],width:0.9f,height:0.9f,response:1b}
summon interaction 2014.4 122.05 -0.5 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_c3_6"],width:0.9f,height:0.9f,response:1b}
summon interaction 2014.4 122.05 0.5 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_c3_7"],width:0.9f,height:0.9f,response:1b}
summon interaction 2014.4 122.05 1.5 {Tags:["sol","sol.r2","sol.r2d","sol.r2i","sol.k2_c3_8"],width:0.9f,height:0.9f,response:1b}
function solstice:r2/c3_lights
summon text_display 2014.95 125.5 0.5 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[90f,0f],billboard:"fixed",text:'["",{"text":"Rallumez toutes les lampes\\n","color":"gray","bold":true},{"text":"(chaque lampe bascule aussi ses voisines)","color":"gray"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
execute if score #debug sol.var matches 1 run function solstice:r2/debug_info
function solstice:r2/show_all
