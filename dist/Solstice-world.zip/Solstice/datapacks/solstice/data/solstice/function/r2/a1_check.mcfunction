execute if score #a1_1 sol.var = #a1t_1 sol.var if score #a1_2 sol.var = #a1t_2 sol.var if score #a1_3 sol.var = #a1t_3 sol.var run function solstice:r2/solve_a1
