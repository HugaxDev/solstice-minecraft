scoreboard players set #step sol.var 2
bossbar set solstice:obj name ["",{"text":"◆ ","color":"gold"},{"text":"Rejoignez tous le quai de la gare, au nord","color":"white"},{"text":"  (observez le village en chemin)","color":"gray"}]
function solstice:hints/reset
