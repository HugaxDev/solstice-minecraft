fill 2002 101 -4 2002 103 -4 iron_bars
fill 2004 101 -4 2004 103 -4 iron_bars
fill 2003 101 -3 2003 103 -3 iron_bars
