effect give @s saturation infinite 0 true
