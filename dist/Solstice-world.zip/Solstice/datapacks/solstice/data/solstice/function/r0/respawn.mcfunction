function solstice:r0/cp
