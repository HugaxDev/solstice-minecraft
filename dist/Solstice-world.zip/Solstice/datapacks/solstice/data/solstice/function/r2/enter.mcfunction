execute unless score @s sol.role matches 1..3 run function solstice:roles/fill_vacant
execute unless score @s sol.cp matches 1..4 run scoreboard players set @s sol.cp 1
function solstice:r2/cp
effect give @s night_vision infinite 0 true
