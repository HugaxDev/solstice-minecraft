execute if entity @s[tag=sol.k1_left] if data entity @s interaction on target run function solstice:r1/c/left
execute if entity @s[tag=sol.k1_right] if data entity @s interaction on target run function solstice:r1/c/right
execute if entity @s[tag=sol.k1_fire] if data entity @s interaction on target run function solstice:r1/c/fire
execute if entity @s[tag=sol.k1_valve] if data entity @s interaction on target run function solstice:r1/c/valve
execute if entity @s[tag=sol.k1_coal] if data entity @s interaction on target run function solstice:r1/c/coal
execute if entity @s[tag=sol.k1_hammer] if data entity @s interaction on target run function solstice:r1/c/hammer
execute if entity @s[tag=sol.k1_crank] if data entity @s interaction on target run function solstice:r1/c/crank
execute if entity @s[tag=sol.k1_left] if data entity @s attack on attacker run function solstice:r1/c/left
execute if entity @s[tag=sol.k1_right] if data entity @s attack on attacker run function solstice:r1/c/right
execute if entity @s[tag=sol.k1_fire] if data entity @s attack on attacker run function solstice:r1/c/fire
execute if entity @s[tag=sol.k1_valve] if data entity @s attack on attacker run function solstice:r1/c/valve
execute if entity @s[tag=sol.k1_coal] if data entity @s attack on attacker run function solstice:r1/c/coal
execute if entity @s[tag=sol.k1_hammer] if data entity @s attack on attacker run function solstice:r1/c/hammer
execute if entity @s[tag=sol.k1_crank] if data entity @s attack on attacker run function solstice:r1/c/crank
data remove entity @s interaction
data remove entity @s attack
