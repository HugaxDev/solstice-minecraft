tag @s remove sol.dn
tag @s remove sol.cand
tag @s remove sol.pick
tag @s remove sol.me
tag @s remove sol.oob
tag @s remove sol.prev
tag @s remove sol.ok
tag @s remove sol.here
function solstice:player/clear_role
