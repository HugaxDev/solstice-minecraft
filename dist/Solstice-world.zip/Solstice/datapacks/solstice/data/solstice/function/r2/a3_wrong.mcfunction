scoreboard players set #a3lock sol.var 400
setblock 1988 122 4 lever[face=wall,facing=north,powered=false]
setblock 1990 122 4 lever[face=wall,facing=north,powered=false]
setblock 1992 122 4 lever[face=wall,facing=north,powered=false]
playsound minecraft:entity.generic.extinguish_fire master @a ~ ~ ~ 1 0.6
title @a actionbar {"text":"Court-circuit ! Les leviers se relèvent et le mécanisme se bloque 20 secondes.","color":"red"}
