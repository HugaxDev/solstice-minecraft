tellraw @a ["",{"text":"✖ Trop vite dans la zone lente ! Le train patine et recule au dernier tronçon.","color":"red"}]
function solstice:r1/back
