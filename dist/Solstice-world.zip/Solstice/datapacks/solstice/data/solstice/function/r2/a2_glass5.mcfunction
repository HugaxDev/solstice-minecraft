setblock 1990 113 5 purple_stained_glass
