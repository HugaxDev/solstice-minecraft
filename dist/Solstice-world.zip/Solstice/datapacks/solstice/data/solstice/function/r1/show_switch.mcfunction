execute if score #switch sol.var matches 0 run data modify entity @e[type=text_display,tag=sol.r1sw,limit=1] text set value '["",{"text":"Aiguillage : ◀ GAUCHE","color":"aqua","bold":true}]'
execute if score #switch sol.var matches 1 run data modify entity @e[type=text_display,tag=sol.r1sw,limit=1] text set value '["",{"text":"Aiguillage : DROITE ▶","color":"aqua","bold":true}]'
