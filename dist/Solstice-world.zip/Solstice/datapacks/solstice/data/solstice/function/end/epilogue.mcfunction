scoreboard players set #room sol.var 8
scoreboard players set #step sol.var 0
function solstice:flow/room_setup
function solstice:village/npc_guard
effect clear @a resistance
bossbar set solstice:obj name ["",{"text":"✦ ","color":"gold"},{"text":"Brumeval — le printemps est revenu","color":"green"}]
