data modify entity @e[type=text_display,tag=sol.r1sign,limit=1] text set value '["",{"text":"Gare du Pic du Solstice\\n","color":"aqua","bold":true},{"text":"Terminus !","color":"white"}]'
execute as @a[tag=sol.ro1] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.6 1.2
