fill 1988 111 -4 1988 113 -4 air
fill 1986 111 -4 1986 113 -4 air
fill 1987 111 -3 1987 113 -3 air
particle minecraft:electric_spark 1987.5 112 -2.5 0.6 0.8 0.6 0.1 30 force
playsound minecraft:block.iron_door.open master @a 1987 112 -3 2 0.7
