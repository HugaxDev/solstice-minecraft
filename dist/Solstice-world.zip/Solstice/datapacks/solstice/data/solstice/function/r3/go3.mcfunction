execute unless entity @s[tag=sol.ro3] run return run title @s actionbar {"text":"Cette mission n’est pas la vôtre.","color":"red"}
tp @s 3039.5 101 5.5 180 0
spawnpoint @s 3039 101 5
playsound minecraft:block.portal.travel master @s ~ ~ ~ 0.2 1.6
title @s times 5 40 10
title @s subtitle {"text":"Rapportez : Verre de lune","color":"gray"}
title @s title {"text":"Le Cabinet d’optique","color":"light_purple","bold":true}
