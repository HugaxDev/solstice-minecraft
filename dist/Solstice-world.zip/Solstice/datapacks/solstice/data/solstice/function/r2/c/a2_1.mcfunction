scoreboard players set #bit sol.var 1
function solstice:r2/a2_toggle
playsound minecraft:item.bucket.empty master @a ~ ~ ~ 0.8 1.2
function solstice:r2/a2_after
