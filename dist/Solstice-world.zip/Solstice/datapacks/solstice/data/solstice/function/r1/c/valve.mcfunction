execute if score @s sol.cool matches 1.. run return 0
scoreboard players set @s sol.cool 6
execute unless entity @s[tag=sol.ro2] run return run title @s actionbar {"text":"Ce n’est pas votre poste : c’est celui du Chauffeur.","color":"red"}
scoreboard players remove #press sol.var 20
execute if score #press sol.var matches ..-1 run scoreboard players set #press sol.var 0
playsound minecraft:block.fire.extinguish master @a ~ ~ ~ 1 1.4
particle minecraft:cloud 983.5 103.5 -1.5 0.3 0.4 0.3 0.05 25
