scoreboard players set #lc sol.var 0
execute as @a if items entity @s container.* lantern[custom_data~{sol:{lantern:1b}}] run scoreboard players add #lc sol.var 1
execute as @a if items entity @s weapon.offhand lantern[custom_data~{sol:{lantern:1b}}] run scoreboard players add #lc sol.var 1
