clear @s *[!custom_data~{sol:{keep:1b}}]
