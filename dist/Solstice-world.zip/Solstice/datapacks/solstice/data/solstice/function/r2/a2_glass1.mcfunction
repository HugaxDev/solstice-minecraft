setblock 1990 113 5 red_stained_glass
