execute if score @s sol.role matches 1 if score @s sol.cp matches 1 run return run function solstice:r2/cp_1_1
execute if score @s sol.role matches 1 if score @s sol.cp matches 2 run return run function solstice:r2/cp_1_2
execute if score @s sol.role matches 1 if score @s sol.cp matches 3 run return run function solstice:r2/cp_1_3
execute if score @s sol.role matches 2 if score @s sol.cp matches 1 run return run function solstice:r2/cp_2_1
execute if score @s sol.role matches 2 if score @s sol.cp matches 2 run return run function solstice:r2/cp_2_2
execute if score @s sol.role matches 2 if score @s sol.cp matches 3 run return run function solstice:r2/cp_2_3
execute if score @s sol.role matches 3 if score @s sol.cp matches 1 run return run function solstice:r2/cp_3_1
execute if score @s sol.role matches 3 if score @s sol.cp matches 2 run return run function solstice:r2/cp_3_2
execute if score @s sol.role matches 3 if score @s sol.cp matches 3 run return run function solstice:r2/cp_3_3
execute if score @s sol.cp matches 4 run return run tp @s 2000.5 131 0.5
tp @s 2000.5 101 1.5 180 0
