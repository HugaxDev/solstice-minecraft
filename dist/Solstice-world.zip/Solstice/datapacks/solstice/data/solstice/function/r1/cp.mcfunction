execute if score @s sol.role matches 1 run return run function solstice:r1/cp1
execute if score @s sol.role matches 2 run return run function solstice:r1/cp2
execute if score @s sol.role matches 3 run return run function solstice:r1/cp3
function solstice:r1/cp0
