execute if score #ended sol.var matches 1 run return 0
scoreboard players set #ended sol.var 1
scoreboard players set #endt sol.var 0
advancement grant @a only solstice:room/r7
kill @e[type=!player,tag=sol.mob]
execute as @a run function solstice:flow/trans_player
effect give @a resistance 1000000 255 true
