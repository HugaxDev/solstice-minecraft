function solstice:r7/seasons3
function solstice:r7/fireworks
