title @a times 10 60 20
title @a subtitle {"text":"La Tour des Engrenages est vaincue","color":"gray"}
title @a title {"text":"Réunis au sommet !","color":"gold","bold":true}
tellraw @a ["",{"text":"Maître Orel","color":"gold","bold":true},{"text":" » ","color":"dark_gray"},{"text":"Magnifique. Mes engrenages n’avaient pas autant tourné depuis mon dernier anniversaire.","color":"yellow"}]
function solstice:flow/complete
