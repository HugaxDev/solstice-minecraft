function solstice:rooms/cp
title @s actionbar {"text":"Le temps vous ramène en arrière…","color":"dark_aqua"}
playsound minecraft:block.respawn_anchor.deplete master @s ~ ~ ~ 0.5 1.4
