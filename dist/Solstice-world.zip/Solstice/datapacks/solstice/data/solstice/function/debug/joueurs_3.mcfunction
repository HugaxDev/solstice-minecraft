scoreboard players set #need sol.var 3
scoreboard players set #debug sol.var 0
scoreboard players set #win sol.var 60
function solstice:roles/revac
tellraw @a ["",{"text":"[debug] Partie réglée pour 3 joueur(s).","color":"red"},{"text":"","color":"gray"}]
