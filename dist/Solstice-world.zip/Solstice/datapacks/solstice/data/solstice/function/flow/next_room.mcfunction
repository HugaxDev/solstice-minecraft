scoreboard players set #trans sol.var 0
scoreboard players add #room sol.var 1
execute as @a run function solstice:player/clear_role
function solstice:flow/room_setup
function solstice:flow/start_room
function solstice:flow/refresh_obj
