tellraw @a ["",{"text":"Plus bas, les cloches du Sanctuaire sonnent l’alarme : les gardiens se sont réveillés.","color":"white","italic":true}]
execute as @a at @s run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.8 0.9
