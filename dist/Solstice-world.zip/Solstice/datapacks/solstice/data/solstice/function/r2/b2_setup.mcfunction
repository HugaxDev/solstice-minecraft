summon text_display 2006.05 115.2 2.5 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[-90f,0f],billboard:"fixed",text:'["",{"text":"Inscription gravée dans la pierre :","color":"gray"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
execute if score #b2seq sol.var matches 0 run summon text_display 2006.05 114.2 2.5 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[-90f,0f],billboard:"fixed",text:'["",{"text":"☀   ☾   ✦   ❄","color":"aqua","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.3f,1.3f,1.3f]}}
execute if score #b2seq sol.var matches 1 run summon text_display 2006.05 114.2 2.5 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[-90f,0f],billboard:"fixed",text:'["",{"text":"✦   ☀   ❄   ☾","color":"aqua","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.3f,1.3f,1.3f]}}
execute if score #b2seq sol.var matches 2 run summon text_display 2006.05 114.2 2.5 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[-90f,0f],billboard:"fixed",text:'["",{"text":"☾   ❄   ☀   ✦","color":"aqua","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.3f,1.3f,1.3f]}}
execute if score #b2seq sol.var matches 3 run summon text_display 2006.05 114.2 2.5 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[-90f,0f],billboard:"fixed",text:'["",{"text":"❄   ✦   ☾   ☀","color":"aqua","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.3f,1.3f,1.3f]}}
execute if score #b2seq sol.var matches 4 run summon text_display 2006.05 114.2 2.5 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[-90f,0f],billboard:"fixed",text:'["",{"text":"☀   ✦   ☾   ❄","color":"aqua","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.3f,1.3f,1.3f]}}
execute if score #b2seq sol.var matches 5 run summon text_display 2006.05 114.2 2.5 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[-90f,0f],billboard:"fixed",text:'["",{"text":"✦   ❄   ☀   ☾","color":"aqua","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.3f,1.3f,1.3f]}}
summon text_display 1994.95 115.4 2.5 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[90f,0f],billboard:"fixed",text:'["",{"text":"Table des signes","color":"gold","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]}}
execute if score #b2leg sol.var matches 0 run summon text_display 1994.95 113.9 2.5 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[90f,0f],billboard:"fixed",text:'["",{"text":"☀  =  1\\n☾  =  2\\n✦  =  3\\n❄  =  4","color":"white"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]}}
execute if score #b2leg sol.var matches 1 run summon text_display 1994.95 113.9 2.5 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[90f,0f],billboard:"fixed",text:'["",{"text":"☀  =  3\\n☾  =  1\\n✦  =  4\\n❄  =  2","color":"white"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]}}
execute if score #b2leg sol.var matches 2 run summon text_display 1994.95 113.9 2.5 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[90f,0f],billboard:"fixed",text:'["",{"text":"☀  =  2\\n☾  =  4\\n✦  =  1\\n❄  =  3","color":"white"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]}}
execute if score #b2leg sol.var matches 3 run summon text_display 1994.95 113.9 2.5 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[90f,0f],billboard:"fixed",text:'["",{"text":"☀  =  4\\n☾  =  3\\n✦  =  2\\n❄  =  1","color":"white"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]}}
execute if score #b2leg sol.var matches 4 run summon text_display 1994.95 113.9 2.5 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[90f,0f],billboard:"fixed",text:'["",{"text":"☀  =  1\\n☾  =  3\\n✦  =  2\\n❄  =  4","color":"white"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]}}
execute if score #b2leg sol.var matches 5 run summon text_display 1994.95 113.9 2.5 {Tags:["sol","sol.r2","sol.r2d"],Rotation:[90f,0f],billboard:"fixed",text:'["",{"text":"☀  =  2\\n☾  =  1\\n✦  =  4\\n❄  =  3","color":"white"}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]}}
execute if score #b2seq sol.var matches 0 if score #b2leg sol.var matches 0 run scoreboard players set #b2code sol.var 1234
execute if score #b2seq sol.var matches 0 if score #b2leg sol.var matches 1 run scoreboard players set #b2code sol.var 3142
execute if score #b2seq sol.var matches 0 if score #b2leg sol.var matches 2 run scoreboard players set #b2code sol.var 2413
execute if score #b2seq sol.var matches 0 if score #b2leg sol.var matches 3 run scoreboard players set #b2code sol.var 4321
execute if score #b2seq sol.var matches 0 if score #b2leg sol.var matches 4 run scoreboard players set #b2code sol.var 1324
execute if score #b2seq sol.var matches 0 if score #b2leg sol.var matches 5 run scoreboard players set #b2code sol.var 2143
execute if score #b2seq sol.var matches 1 if score #b2leg sol.var matches 0 run scoreboard players set #b2code sol.var 3142
execute if score #b2seq sol.var matches 1 if score #b2leg sol.var matches 1 run scoreboard players set #b2code sol.var 4321
execute if score #b2seq sol.var matches 1 if score #b2leg sol.var matches 2 run scoreboard players set #b2code sol.var 1234
execute if score #b2seq sol.var matches 1 if score #b2leg sol.var matches 3 run scoreboard players set #b2code sol.var 2413
execute if score #b2seq sol.var matches 1 if score #b2leg sol.var matches 4 run scoreboard players set #b2code sol.var 2143
execute if score #b2seq sol.var matches 1 if score #b2leg sol.var matches 5 run scoreboard players set #b2code sol.var 4231
execute if score #b2seq sol.var matches 2 if score #b2leg sol.var matches 0 run scoreboard players set #b2code sol.var 2413
execute if score #b2seq sol.var matches 2 if score #b2leg sol.var matches 1 run scoreboard players set #b2code sol.var 1234
execute if score #b2seq sol.var matches 2 if score #b2leg sol.var matches 2 run scoreboard players set #b2code sol.var 4321
execute if score #b2seq sol.var matches 2 if score #b2leg sol.var matches 3 run scoreboard players set #b2code sol.var 3142
execute if score #b2seq sol.var matches 2 if score #b2leg sol.var matches 4 run scoreboard players set #b2code sol.var 3412
execute if score #b2seq sol.var matches 2 if score #b2leg sol.var matches 5 run scoreboard players set #b2code sol.var 1324
execute if score #b2seq sol.var matches 3 if score #b2leg sol.var matches 0 run scoreboard players set #b2code sol.var 4321
execute if score #b2seq sol.var matches 3 if score #b2leg sol.var matches 1 run scoreboard players set #b2code sol.var 2413
execute if score #b2seq sol.var matches 3 if score #b2leg sol.var matches 2 run scoreboard players set #b2code sol.var 3142
execute if score #b2seq sol.var matches 3 if score #b2leg sol.var matches 3 run scoreboard players set #b2code sol.var 1234
execute if score #b2seq sol.var matches 3 if score #b2leg sol.var matches 4 run scoreboard players set #b2code sol.var 4231
execute if score #b2seq sol.var matches 3 if score #b2leg sol.var matches 5 run scoreboard players set #b2code sol.var 3412
execute if score #b2seq sol.var matches 4 if score #b2leg sol.var matches 0 run scoreboard players set #b2code sol.var 1324
execute if score #b2seq sol.var matches 4 if score #b2leg sol.var matches 1 run scoreboard players set #b2code sol.var 3412
execute if score #b2seq sol.var matches 4 if score #b2leg sol.var matches 2 run scoreboard players set #b2code sol.var 2143
execute if score #b2seq sol.var matches 4 if score #b2leg sol.var matches 3 run scoreboard players set #b2code sol.var 4231
execute if score #b2seq sol.var matches 4 if score #b2leg sol.var matches 4 run scoreboard players set #b2code sol.var 1234
execute if score #b2seq sol.var matches 4 if score #b2leg sol.var matches 5 run scoreboard players set #b2code sol.var 2413
execute if score #b2seq sol.var matches 5 if score #b2leg sol.var matches 0 run scoreboard players set #b2code sol.var 3412
execute if score #b2seq sol.var matches 5 if score #b2leg sol.var matches 1 run scoreboard players set #b2code sol.var 4231
execute if score #b2seq sol.var matches 5 if score #b2leg sol.var matches 2 run scoreboard players set #b2code sol.var 1324
execute if score #b2seq sol.var matches 5 if score #b2leg sol.var matches 3 run scoreboard players set #b2code sol.var 2143
execute if score #b2seq sol.var matches 5 if score #b2leg sol.var matches 4 run scoreboard players set #b2code sol.var 2413
execute if score #b2seq sol.var matches 5 if score #b2leg sol.var matches 5 run scoreboard players set #b2code sol.var 4321
