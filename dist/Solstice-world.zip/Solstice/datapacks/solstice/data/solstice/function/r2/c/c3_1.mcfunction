function solstice:r2/c3_press1
playsound minecraft:block.lever.click master @a ~ ~ ~ 1 1.3
