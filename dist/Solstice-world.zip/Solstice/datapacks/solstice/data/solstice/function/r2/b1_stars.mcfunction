kill @e[type=!player,tag=sol.b1star]
scoreboard players set #b1n sol.var 0
execute store result score #rnd sol.var run random value 0..1
execute if score #rnd sol.var matches 1 run summon text_display 2014.95 106 -2.5 {Tags:["sol","sol.r2","sol.r2d","sol.b1star"],Rotation:[90f,0f],billboard:"fixed",text:'["",{"text":"✹","color":"gold","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.6f,1.6f,1.6f]}}
execute if score #rnd sol.var matches 1 run scoreboard players add #b1n sol.var 1
execute store result score #rnd sol.var run random value 0..1
execute if score #rnd sol.var matches 1 run summon text_display 2014.95 107 -2.5 {Tags:["sol","sol.r2","sol.r2d","sol.b1star"],Rotation:[90f,0f],billboard:"fixed",text:'["",{"text":"✹","color":"gold","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.6f,1.6f,1.6f]}}
execute if score #rnd sol.var matches 1 run scoreboard players add #b1n sol.var 1
execute store result score #rnd sol.var run random value 0..1
execute if score #rnd sol.var matches 1 run summon text_display 2014.95 106 0.5 {Tags:["sol","sol.r2","sol.r2d","sol.b1star"],Rotation:[90f,0f],billboard:"fixed",text:'["",{"text":"✹","color":"gold","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.6f,1.6f,1.6f]}}
execute if score #rnd sol.var matches 1 run scoreboard players add #b1n sol.var 1
execute store result score #rnd sol.var run random value 0..1
execute if score #rnd sol.var matches 1 run summon text_display 2014.95 107 0.5 {Tags:["sol","sol.r2","sol.r2d","sol.b1star"],Rotation:[90f,0f],billboard:"fixed",text:'["",{"text":"✹","color":"gold","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.6f,1.6f,1.6f]}}
execute if score #rnd sol.var matches 1 run scoreboard players add #b1n sol.var 1
execute store result score #rnd sol.var run random value 0..1
execute if score #rnd sol.var matches 1 run summon text_display 2014.95 106 3.5 {Tags:["sol","sol.r2","sol.r2d","sol.b1star"],Rotation:[90f,0f],billboard:"fixed",text:'["",{"text":"✹","color":"gold","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.6f,1.6f,1.6f]}}
execute if score #rnd sol.var matches 1 run scoreboard players add #b1n sol.var 1
execute store result score #rnd sol.var run random value 0..1
execute if score #rnd sol.var matches 1 run summon text_display 2014.95 107 3.5 {Tags:["sol","sol.r2","sol.r2d","sol.b1star"],Rotation:[90f,0f],billboard:"fixed",text:'["",{"text":"✹","color":"gold","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.6f,1.6f,1.6f]}}
execute if score #rnd sol.var matches 1 run scoreboard players add #b1n sol.var 1
execute store result score #rnd sol.var run random value 0..1
execute if score #rnd sol.var matches 1 run summon text_display 2007.5 106 4.95 {Tags:["sol","sol.r2","sol.r2d","sol.b1star"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"✹","color":"gold","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.6f,1.6f,1.6f]}}
execute if score #rnd sol.var matches 1 run scoreboard players add #b1n sol.var 1
execute store result score #rnd sol.var run random value 0..1
execute if score #rnd sol.var matches 1 run summon text_display 2013.5 106 4.95 {Tags:["sol","sol.r2","sol.r2d","sol.b1star"],Rotation:[180f,0f],billboard:"fixed",text:'["",{"text":"✹","color":"gold","bold":true}]',background:-2147483648,shadow:1b,line_width:220,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.6f,1.6f,1.6f]}}
execute if score #rnd sol.var matches 1 run scoreboard players add #b1n sol.var 1
execute if score #b1n sol.var matches ..1 run function solstice:r2/b1_stars
