scoreboard players set @s sol.joined 1
scoreboard players reset @s sol.room
scoreboard players set @s sol.role 0
scoreboard players set @s sol.deaths 0
scoreboard players set @s sol.dall 0
scoreboard players set @s sol.leave 0
scoreboard players set @s sol.down 0
scoreboard players set @s sol.use 0
scoreboard players set @s sol.horn 0
scoreboard players set @s sol.sneak 0
scoreboard players set @s sol.vote 0
function solstice:player/clear_tags
clear @s
effect clear @s
gamemode adventure @s
advancement grant @s only solstice:root
