tellraw @a ["",{"text":"Le dernier sceau cède. Le silence retombe sur le Sanctuaire.","color":"white","italic":true}]
execute as @a at @s run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.8 0.9
