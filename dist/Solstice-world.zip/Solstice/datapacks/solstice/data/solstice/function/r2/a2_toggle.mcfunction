scoreboard players operation #tmp sol.var = #a2m sol.var
scoreboard players operation #tmp sol.var /= #bit sol.var
scoreboard players operation #tmp sol.var %= #c2 sol.var
execute if score #tmp sol.var matches 1 run scoreboard players operation #a2m sol.var -= #bit sol.var
execute if score #tmp sol.var matches 0 run scoreboard players operation #a2m sol.var += #bit sol.var
