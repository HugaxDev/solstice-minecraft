function solstice:r2/c3_flip8
function solstice:r2/c3_flip5
function solstice:r2/c3_flip7
