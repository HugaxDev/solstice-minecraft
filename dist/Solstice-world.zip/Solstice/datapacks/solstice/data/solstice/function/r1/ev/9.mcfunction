execute if score #press sol.var matches ..59 run return run function solstice:r1/err_tunnel
scoreboard players add #ev sol.var 1
scoreboard players set #signed sol.var 0
scoreboard players set #ev_cross sol.var 0
function solstice:r1/sign_free
tellraw @a ["",{"text":"✔ Le train sort du tunnel dans un nuage de vapeur !","color":"green"}]
