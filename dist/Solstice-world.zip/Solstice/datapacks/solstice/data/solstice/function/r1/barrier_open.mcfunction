scoreboard players set #bopen sol.var 1
tellraw @a ["",{"text":"✔ Barrière ouverte !","color":"yellow"}]
execute as @a at @s run playsound minecraft:block.fence_gate.open master @s ~ ~ ~ 1 0.8
