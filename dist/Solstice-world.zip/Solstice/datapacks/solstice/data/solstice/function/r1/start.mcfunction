function solstice:r1/entities
kill @e[type=!player,tag=sol.r1mob]
scoreboard players set #errors sol.var 0
scoreboard players set #step sol.var 0
scoreboard players set #r1t sol.var 0
function solstice:r1/reset_run
scoreboard players set #dist sol.var 0
scoreboard players set #ev sol.var 0
function solstice:roles/draw
function solstice:r1/announce
bossbar set solstice:train players @a
bossbar set solstice:train visible true
bossbar set solstice:obj name ["",{"text":"◆ ","color":"gold"},{"text":"L’Express démarre : chacun à son poste !","color":"white"}]
tellraw @a ["",{"text":"Maître Orel","color":"gold","bold":true},{"text":" » ","color":"dark_gray"},{"text":"Bienvenue à bord ! Le train ne s’arrête plus, alors on va le conduire en marche. Chacun son poste, et parlez-vous : c’est tout le secret des chemins de fer.","color":"yellow"}]
