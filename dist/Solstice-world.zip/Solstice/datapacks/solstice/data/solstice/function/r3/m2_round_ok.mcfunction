scoreboard players add #m2round sol.var 1
scoreboard players set #m2in sol.var 0
playsound minecraft:entity.player.levelup master @a ~ ~ ~ 0.6 1.4
execute if score #m2round sol.var matches 4.. run return run function solstice:r3/m2_solved
title @a[tag=sol.ro2] actionbar {"text":"Juste ! Une mélodie plus longue arrive…","color":"aqua"}
scoreboard players set #m2play sol.var 1
scoreboard players set #m2pt sol.var -20
