execute as @a[scores={sol.role=1}] run title @s times 10 70 20
execute as @a[scores={sol.role=1}] run title @s subtitle {"text":"Votre mission : rapporter la pièce « Cage de laiton ».","color":"gray"}
execute as @a[scores={sol.role=1}] run title @s title {"text":"Le Grenier aux Caisses","color":"gold","bold":true}
execute as @a[scores={sol.role=2}] run title @s times 10 70 20
execute as @a[scores={sol.role=2}] run title @s subtitle {"text":"Votre mission : rapporter la pièce « Mèche éternelle ».","color":"gray"}
execute as @a[scores={sol.role=2}] run title @s title {"text":"La Cave aux Cloches","color":"aqua","bold":true}
execute as @a[scores={sol.role=3}] run title @s times 10 70 20
execute as @a[scores={sol.role=3}] run title @s subtitle {"text":"Votre mission : rapporter la pièce « Verre de lune ».","color":"gray"}
execute as @a[scores={sol.role=3}] run title @s title {"text":"Le Cabinet d’optique","color":"light_purple","bold":true}
tellraw @a ["",{"text":"⚄ Tirage au sort","color":"yellow","bold":true}]
execute if score #vac1 sol.var matches 0 run tellraw @a ["",{"text":"  • ","color":"dark_gray"},{"text":"Le Grenier aux Caisses","color":"gold","bold":true},{"text":" : ","color":"gray"},{"selector":"@a[scores={sol.role=1}]","color":"white"}]
execute if score #vac1 sol.var matches 1 run tellraw @a ["",{"text":"  • ","color":"dark_gray"},{"text":"Le Grenier aux Caisses","color":"gold","bold":true},{"text":" : vacant (tout le monde peut le jouer)","color":"gray"}]
execute if score #vac2 sol.var matches 0 run tellraw @a ["",{"text":"  • ","color":"dark_gray"},{"text":"La Cave aux Cloches","color":"aqua","bold":true},{"text":" : ","color":"gray"},{"selector":"@a[scores={sol.role=2}]","color":"white"}]
execute if score #vac2 sol.var matches 1 run tellraw @a ["",{"text":"  • ","color":"dark_gray"},{"text":"La Cave aux Cloches","color":"aqua","bold":true},{"text":" : vacant (tout le monde peut le jouer)","color":"gray"}]
execute if score #vac3 sol.var matches 0 run tellraw @a ["",{"text":"  • ","color":"dark_gray"},{"text":"Le Cabinet d’optique","color":"light_purple","bold":true},{"text":" : ","color":"gray"},{"selector":"@a[scores={sol.role=3}]","color":"white"}]
execute if score #vac3 sol.var matches 1 run tellraw @a ["",{"text":"  • ","color":"dark_gray"},{"text":"Le Cabinet d’optique","color":"light_purple","bold":true},{"text":" : vacant (tout le monde peut le jouer)","color":"gray"}]
execute as @a at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.2
