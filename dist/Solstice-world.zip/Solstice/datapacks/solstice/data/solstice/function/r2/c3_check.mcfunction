execute if score #c3scr sol.var matches 1 run return 0
execute if score #c3_0 sol.var matches 1 if score #c3_1 sol.var matches 1 if score #c3_2 sol.var matches 1 if score #c3_3 sol.var matches 1 if score #c3_4 sol.var matches 1 if score #c3_5 sol.var matches 1 if score #c3_6 sol.var matches 1 if score #c3_7 sol.var matches 1 if score #c3_8 sol.var matches 1 run function solstice:r2/solve_c3
