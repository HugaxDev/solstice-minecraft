tag @s remove sol.dn
scoreboard players set @s sol.down 0
execute if entity @s[gamemode=spectator] run spectate
gamemode adventure @s
effect give @s resistance 12 255 true
effect give @s slowness 12 6 true
playsound minecraft:block.bell.resonate master @s ~ ~ ~ 1 0.7
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.8 1
