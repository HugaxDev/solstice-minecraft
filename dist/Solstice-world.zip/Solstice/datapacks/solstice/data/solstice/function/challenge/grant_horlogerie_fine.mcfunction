advancement grant @a only solstice:challenge/horlogerie_fine
tellraw @a ["",{"text":"★ Défi caché relevé : ","color":"aqua","bold":true},{"text":"Horlogerie fine","color":"white"}]
execute as @a run function solstice:challenge/check_all
