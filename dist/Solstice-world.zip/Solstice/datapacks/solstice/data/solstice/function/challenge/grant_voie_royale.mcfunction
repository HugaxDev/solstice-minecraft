advancement grant @a only solstice:challenge/voie_royale
tellraw @a ["",{"text":"★ Défi caché relevé : ","color":"aqua","bold":true},{"text":"Voie royale","color":"white"}]
execute as @a run function solstice:challenge/check_all
