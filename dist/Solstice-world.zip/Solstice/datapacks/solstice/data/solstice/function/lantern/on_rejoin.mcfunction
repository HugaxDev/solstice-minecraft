execute unless score #lantern sol.var matches 1 run return 0
tag @s add sol.me
scoreboard players set #lo sol.var 0
execute as @a[tag=!sol.me] if items entity @s container.* lantern[custom_data~{sol:{lantern:1b}}] run scoreboard players add #lo sol.var 1
execute as @a[tag=!sol.me] if items entity @s weapon.offhand lantern[custom_data~{sol:{lantern:1b}}] run scoreboard players add #lo sol.var 1
tag @s remove sol.me
execute if score #lo sol.var matches 1.. run clear @s lantern[custom_data~{sol:{lantern:1b}}]
