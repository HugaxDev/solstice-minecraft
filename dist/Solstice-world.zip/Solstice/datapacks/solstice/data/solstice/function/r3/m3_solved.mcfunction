execute if score #m3done sol.var matches 1 run return 0
scoreboard players set #m3done sol.var 1
setblock 3038 101 5 air
setblock 3043 101 -3 sea_lantern
tellraw @a ["",{"text":"✦ Cabinet : la lumière touche la cible, la vitrine s’ouvre.","color":"light_purple"}]
