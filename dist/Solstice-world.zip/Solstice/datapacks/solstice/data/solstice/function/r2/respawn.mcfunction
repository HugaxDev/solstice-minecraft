function solstice:r2/cp
