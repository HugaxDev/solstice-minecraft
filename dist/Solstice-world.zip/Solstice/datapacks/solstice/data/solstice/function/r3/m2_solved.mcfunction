scoreboard players set #m2done sol.var 1
setblock 2996 102 37 air
tellraw @a ["",{"text":"✦ Cave : les cloches ont chanté juste, la vitrine s’ouvre.","color":"aqua"}]
