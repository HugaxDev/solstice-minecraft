execute as @e[type=interaction,tag=sol.r1i] at @s if data entity @s interaction run function solstice:r1/clicked
execute as @e[type=interaction,tag=sol.r1i] at @s if data entity @s attack run function solstice:r1/clicked
scoreboard players add #r1t sol.var 1
execute if score #step sol.var matches 0 if score #r1t sol.var matches 200.. run function solstice:r1/go
execute if score #step sol.var matches 0 run return 0
execute if score #pause sol.var matches 1.. run scoreboard players remove #pause sol.var 1
scoreboard players operation #m8 sol.var = #r1t sol.var
scoreboard players operation #m8 sol.var %= #c8 sol.var
execute if score #m8 sol.var matches 0 run scoreboard players remove #press sol.var 1
execute if score #m4 sol.var matches 0 as @e[tag=sol.r1mob] at @s if entity @s[x=979,y=99,z=-4,dx=16,dy=6,dz=8] run scoreboard players remove #press sol.var 1
execute if score #press sol.var matches ..-1 run scoreboard players set #press sol.var 0
scoreboard players set #speed sol.var 0
execute if score #press sol.var matches 10..39 run scoreboard players set #speed sol.var 1
execute if score #press sol.var matches 40..74 run scoreboard players set #speed sol.var 2
execute if score #press sol.var matches 75.. run scoreboard players set #speed sol.var 3
execute if score #pause sol.var matches 1.. run scoreboard players set #speed sol.var 0
execute if score #pause sol.var matches 0 run scoreboard players operation #dist sol.var += #speed sol.var
execute store result bossbar solstice:train value run scoreboard players get #dist sol.var
execute if score #press sol.var matches 101.. run return run function solstice:r1/err_over
execute if score #pause sol.var matches 0 if score #press sol.var matches ..9 run scoreboard players add #stall sol.var 1
execute if score #press sol.var matches 10.. run scoreboard players set #stall sol.var 0
execute if score #stall sol.var matches 120.. run return run function solstice:r1/err_stall
execute if score #lim sol.var matches 1 if score #speed sol.var matches 2.. run scoreboard players add #over sol.var 1
execute if score #over sol.var matches 40.. run return run function solstice:r1/err_derail
function solstice:r1/events
execute as @e[tag=sol.r1mob] at @s if entity @s[y=-64,dy=158] run function solstice:r1/mob_fell
execute if score #m4 sol.var matches 0 run function solstice:r1/scenery
execute if score #m20 sol.var matches 0 run function solstice:r1/bars
execute if score #step sol.var matches 1.. run function solstice:r1/section
