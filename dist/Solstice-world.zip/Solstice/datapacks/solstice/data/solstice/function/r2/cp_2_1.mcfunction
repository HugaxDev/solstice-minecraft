tp @s 2000.5 101 1.5 180 0
spawnpoint @s 2000 101 1
