scoreboard players add #tick sol.var 1
scoreboard players operation #m20 sol.var = #tick sol.var
scoreboard players operation #m20 sol.var %= #c20 sol.var
scoreboard players operation #m4 sol.var = #tick sol.var
scoreboard players operation #m4 sol.var %= #c4 sol.var
execute as @a unless score @s sol.joined matches 1 run function solstice:player/first_join
function solstice:flow/tick
execute as @a at @s run function solstice:player/tick
