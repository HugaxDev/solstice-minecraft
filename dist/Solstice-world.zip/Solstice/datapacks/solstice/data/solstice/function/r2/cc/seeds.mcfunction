execute if score @s sol.cool matches 1.. run return 0
scoreboard players set @s sol.cool 5
execute unless entity @s[tag=sol.ro3] run return run title @s actionbar {"text":"Ce mécanisme n’est pas dans votre puits.","color":"red"}
function solstice:r2/c/seeds
