scoreboard players set #zl sol.var 1
execute if score #room sol.var matches 0 unless loaded 0 100 0 run scoreboard players set #zl sol.var 0
execute if score #room sol.var matches 1 unless loaded 1000 100 0 run scoreboard players set #zl sol.var 0
execute if score #room sol.var matches 2 unless loaded 2000 100 0 run scoreboard players set #zl sol.var 0
execute if score #room sol.var matches 3 unless loaded 3000 100 0 run scoreboard players set #zl sol.var 0
execute if score #room sol.var matches 4 unless loaded 4000 100 0 run scoreboard players set #zl sol.var 0
execute if score #room sol.var matches 5 unless loaded 5000 100 -15 run scoreboard players set #zl sol.var 0
execute if score #room sol.var matches 6 unless loaded 6000 100 0 run scoreboard players set #zl sol.var 0
execute if score #room sol.var matches 6 unless loaded 6000 100 200 run scoreboard players set #zl sol.var 0
execute if score #room sol.var matches 6 unless loaded 6000 100 400 run scoreboard players set #zl sol.var 0
execute if score #room sol.var matches 6 unless loaded 6000 100 600 run scoreboard players set #zl sol.var 0
execute if score #room sol.var matches 7 unless loaded 7000 100 0 run scoreboard players set #zl sol.var 0
execute if score #room sol.var matches 8 unless loaded 0 100 0 run scoreboard players set #zl sol.var 0
