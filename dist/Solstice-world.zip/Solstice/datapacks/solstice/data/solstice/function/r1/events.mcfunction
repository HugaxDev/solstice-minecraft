execute if score #ev sol.var matches 0 if score #signed sol.var matches 0 if score #dist sol.var matches 400.. run function solstice:r1/signon/0
execute if score #ev sol.var matches 0 if score #dist sol.var matches 1100.. run return run function solstice:r1/ev/0
execute if score #ev sol.var matches 1 if score #signed sol.var matches 0 if score #dist sol.var matches 1700.. run function solstice:r1/signon/1
execute if score #ev sol.var matches 1 if score #dist sol.var matches 1700.. run return run function solstice:r1/ev/1
execute if score #ev sol.var matches 2 if score #signed sol.var matches 0 if score #dist sol.var matches 1700.. run function solstice:r1/signon/2
execute if score #ev sol.var matches 2 if score #dist sol.var matches 2400.. run return run function solstice:r1/ev/2
execute if score #ev sol.var matches 3 if score #signed sol.var matches 0 if score #dist sol.var matches 2800.. run function solstice:r1/signon/3
execute if score #ev sol.var matches 3 if score #dist sol.var matches 3300.. run return run function solstice:r1/ev/3
execute if score #ev sol.var matches 4 if score #signed sol.var matches 0 if score #dist sol.var matches 3200.. run function solstice:r1/signon/4
execute if score #ev sol.var matches 4 if score #dist sol.var matches 3900.. run return run function solstice:r1/ev/4
execute if score #ev sol.var matches 5 if score #signed sol.var matches 0 if score #dist sol.var matches 3400.. run function solstice:r1/signon/5
execute if score #ev sol.var matches 5 if score #dist sol.var matches 4100.. run return run function solstice:r1/ev/5
execute if score #ev sol.var matches 6 if score #signed sol.var matches 0 if score #dist sol.var matches 4400.. run function solstice:r1/signon/6
execute if score #ev sol.var matches 6 if score #dist sol.var matches 4400.. run return run function solstice:r1/ev/6
execute if score #ev sol.var matches 7 if score #signed sol.var matches 0 if score #dist sol.var matches 4400.. run function solstice:r1/signon/7
execute if score #ev sol.var matches 7 if score #dist sol.var matches 5100.. run return run function solstice:r1/ev/7
execute if score #ev sol.var matches 8 if score #signed sol.var matches 0 if score #dist sol.var matches 6000.. run function solstice:r1/signon/8
execute if score #ev sol.var matches 8 if score #dist sol.var matches 6000.. run return run function solstice:r1/ev/8
execute if score #ev sol.var matches 9 if score #signed sol.var matches 0 if score #dist sol.var matches 6100.. run function solstice:r1/signon/9
execute if score #ev sol.var matches 9 if score #dist sol.var matches 6800.. run return run function solstice:r1/ev/9
execute if score #ev sol.var matches 10 if score #signed sol.var matches 0 if score #dist sol.var matches 7000.. run function solstice:r1/signon/10
execute if score #ev sol.var matches 10 if score #dist sol.var matches 7700.. run return run function solstice:r1/ev/10
execute if score #ev sol.var matches 11 if score #signed sol.var matches 0 if score #dist sol.var matches 7500.. run function solstice:r1/signon/11
execute if score #ev sol.var matches 11 if score #dist sol.var matches 8200.. run return run function solstice:r1/ev/11
execute if score #ev sol.var matches 12 if score #signed sol.var matches 0 if score #dist sol.var matches 8400.. run function solstice:r1/signon/12
execute if score #ev sol.var matches 12 if score #dist sol.var matches 8700.. run return run function solstice:r1/ev/12
execute if score #ev sol.var matches 13 if score #signed sol.var matches 0 if score #dist sol.var matches 8600.. run function solstice:r1/signon/13
execute if score #ev sol.var matches 13 if score #dist sol.var matches 9300.. run return run function solstice:r1/ev/13
execute if score #ev sol.var matches 14 if score #signed sol.var matches 0 if score #dist sol.var matches 9400.. run function solstice:r1/signon/14
execute if score #ev sol.var matches 14 if score #dist sol.var matches 9400.. run return run function solstice:r1/ev/14
execute if score #ev sol.var matches 15 if score #signed sol.var matches 0 if score #dist sol.var matches 9800.. run function solstice:r1/signon/15
execute if score #ev sol.var matches 15 if score #dist sol.var matches 10400.. run return run function solstice:r1/ev/15
execute if score #ev sol.var matches 16 if score #signed sol.var matches 0 if score #dist sol.var matches 10200.. run function solstice:r1/signon/16
execute if score #ev sol.var matches 16 if score #dist sol.var matches 10900.. run return run function solstice:r1/ev/16
execute if score #ev sol.var matches 17 if score #signed sol.var matches 0 if score #dist sol.var matches 11300.. run function solstice:r1/signon/17
execute if score #ev sol.var matches 17 if score #dist sol.var matches 12000.. run return run function solstice:r1/ev/17
execute if score #ev sol.var matches 18 if score #signed sol.var matches 0 if score #dist sol.var matches 11899.. run function solstice:r1/signon/18
execute if score #ev sol.var matches 18 if score #dist sol.var matches 12599.. run return run function solstice:r1/ev/18
