execute if score #a2m sol.var matches 0 run function solstice:r2/a2_glass0
execute if score #a2m sol.var matches 1 run function solstice:r2/a2_glass1
execute if score #a2m sol.var matches 2 run function solstice:r2/a2_glass2
execute if score #a2m sol.var matches 4 run function solstice:r2/a2_glass4
execute if score #a2m sol.var matches 3 run function solstice:r2/a2_glass3
execute if score #a2m sol.var matches 6 run function solstice:r2/a2_glass6
execute if score #a2m sol.var matches 5 run function solstice:r2/a2_glass5
execute if score #a2m sol.var matches 7 run function solstice:r2/a2_glass7
execute if score #a2s sol.var matches 0 if score #a2m sol.var = #a2t1 sol.var run function solstice:r2/a2_first
execute if score #a2s sol.var matches 1 if score #a2m sol.var = #a2t2 sol.var run function solstice:r2/solve_a2
