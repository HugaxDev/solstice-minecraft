scoreboard players add #spell sol.var 1
playsound minecraft:block.note_block.pling master @a ~ ~ ~ 1 1.5
title @a actionbar ["",{"text":"Le plancher tinte… ","color":"aqua"},{"score":{"name":"#spell","objective":"sol.var"},"color":"white"},{"text":" / 5","color":"gray"}]
execute if score #spell sol.var matches 5 run function solstice:r3/done
