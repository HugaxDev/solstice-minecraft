scoreboard players operation @s sol.room = #room sol.var
function solstice:player/clear_items
tag @s remove sol.dn
tag @s remove sol.cand
tag @s remove sol.pick
tag @s remove sol.me
tag @s remove sol.oob
tag @s remove sol.ok
tag @s remove sol.here
execute unless score @s sol.rroom = #room sol.var run function solstice:player/clear_role
scoreboard players set @s sol.down 0
execute if entity @s[gamemode=spectator] run spectate
gamemode adventure @s
effect clear @s
function solstice:player/base_effects
attribute @s minecraft:generic.max_health base set 20
attribute @s minecraft:generic.movement_speed base set 0.1
attribute @s minecraft:generic.attack_damage base set 1
attribute @s minecraft:generic.knockback_resistance base set 0
attribute @s minecraft:generic.armor base set 0
effect give @s instant_health 1 5 true
function solstice:story/sync_player
function solstice:rooms/enter
