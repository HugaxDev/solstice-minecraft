tellraw @a ["",{"text":"« Montez, montez ! Il ne s’arrête plus depuis que le temps s’est détraqué. »","color":"white","italic":true}]
execute as @a at @s run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.8 0.9
