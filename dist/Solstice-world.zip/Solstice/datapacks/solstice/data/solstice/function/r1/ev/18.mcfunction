scoreboard players add #ev sol.var 1
scoreboard players set #signed sol.var 0
scoreboard players set #ev_cross sol.var 0
function solstice:r1/sign_free
function solstice:r1/arrived
