tag @s remove sol.dn
execute if entity @s[gamemode=spectator] run function solstice:player/ghost_end
