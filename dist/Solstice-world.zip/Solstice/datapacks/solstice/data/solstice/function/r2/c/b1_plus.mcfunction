scoreboard players add #b1c sol.var 1
execute if score #b1c sol.var matches 10.. run scoreboard players set #b1c sol.var 0
playsound minecraft:block.wooden_button.click_on master @a ~ ~ ~ 1 1.2
function solstice:r2/b1_show
