execute unless entity @s[tag=sol.ro1] run return run title @s actionbar {"text":"Cette mission n’est pas la vôtre.","color":"red"}
tp @s 2999.5 101 -34.5 180 0
spawnpoint @s 2999 101 -34
playsound minecraft:block.portal.travel master @s ~ ~ ~ 0.2 1.6
title @s times 5 40 10
title @s subtitle {"text":"Rapportez : Cage de laiton","color":"gray"}
title @s title {"text":"Le Grenier aux Caisses","color":"gold","bold":true}
