execute unless entity @s[tag=sol.ro2] run return run title @s actionbar {"text":"Cette mission n’est pas la vôtre.","color":"red"}
tp @s 3000.5 101 36.5 0 0
spawnpoint @s 3000 101 36
playsound minecraft:block.portal.travel master @s ~ ~ ~ 0.2 1.6
title @s times 5 40 10
title @s subtitle {"text":"Rapportez : Mèche éternelle","color":"gray"}
title @s title {"text":"La Cave aux Cloches","color":"aqua","bold":true}
