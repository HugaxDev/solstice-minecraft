scoreboard players set #step sol.var 0
scoreboard players set #r0t sol.var 0
function solstice:r0/obj_wait
