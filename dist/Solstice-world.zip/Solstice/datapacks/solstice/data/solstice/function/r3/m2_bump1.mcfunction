scoreboard players add #mel1 sol.var 1
execute if score #mel1 sol.var matches 5.. run scoreboard players set #mel1 sol.var 0
