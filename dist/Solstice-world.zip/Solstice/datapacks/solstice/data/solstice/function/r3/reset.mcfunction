function solstice:r3/entities
fill 2984 101 5 2985 103 6 bookshelf
scoreboard players set #m1done sol.var 0
scoreboard players set #m2done sol.var 0
scoreboard players set #m3done sol.var 0
scoreboard players set #m1got sol.var 0
scoreboard players set #m2got sol.var 0
scoreboard players set #m3got sol.var 0
scoreboard players set #slot1 sol.var 0
scoreboard players set #slot2 sol.var 0
scoreboard players set #slot3 sol.var 0
scoreboard players set #asm sol.var 0
scoreboard players set #m2round sol.var 0
scoreboard players set #m2in sol.var 0
scoreboard players set #m2play sol.var 0
scoreboard players set #m2pt sol.var 0
scoreboard players set #spell sol.var 0
scoreboard players set #r3done sol.var 0
scoreboard players set #m3cfg sol.var 0
setblock 2998 101 -35 glass
setblock 2996 102 37 glass
setblock 3038 101 5 glass
setblock 3043 101 -3 target
function solstice:r3/sk_reset
function solstice:r3/m2_new
function solstice:r3/mir_show
