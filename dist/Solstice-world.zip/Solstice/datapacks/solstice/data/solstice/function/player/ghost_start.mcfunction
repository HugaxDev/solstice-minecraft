gamemode spectator @s
spectate @a[tag=!sol.dn,gamemode=!spectator,sort=nearest,limit=1] @s
title @s times 5 50 10
title @s subtitle {"text":"Vous observez un coéquipier… retour dans 10 secondes.","color":"gray"}
title @s title {"text":"À terre","color":"red","bold":true}
playsound minecraft:entity.player.hurt master @s ~ ~ ~ 1 0.6
