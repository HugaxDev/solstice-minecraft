scoreboard players add #m2pt sol.var 1
scoreboard players operation #m2len sol.var = #m2round sol.var
scoreboard players add #m2len sol.var 2
execute if score #m2pt sol.var matches 20 if score #m2len sol.var matches 1.. if score #mel0 sol.var matches 0 run function solstice:r3/m2_ring0
execute if score #m2pt sol.var matches 20 if score #m2len sol.var matches 1.. if score #mel0 sol.var matches 1 run function solstice:r3/m2_ring1
execute if score #m2pt sol.var matches 20 if score #m2len sol.var matches 1.. if score #mel0 sol.var matches 2 run function solstice:r3/m2_ring2
execute if score #m2pt sol.var matches 20 if score #m2len sol.var matches 1.. if score #mel0 sol.var matches 3 run function solstice:r3/m2_ring3
execute if score #m2pt sol.var matches 20 if score #m2len sol.var matches 1.. if score #mel0 sol.var matches 4 run function solstice:r3/m2_ring4
execute if score #m2pt sol.var matches 34 if score #m2len sol.var matches 2.. if score #mel1 sol.var matches 0 run function solstice:r3/m2_ring0
execute if score #m2pt sol.var matches 34 if score #m2len sol.var matches 2.. if score #mel1 sol.var matches 1 run function solstice:r3/m2_ring1
execute if score #m2pt sol.var matches 34 if score #m2len sol.var matches 2.. if score #mel1 sol.var matches 2 run function solstice:r3/m2_ring2
execute if score #m2pt sol.var matches 34 if score #m2len sol.var matches 2.. if score #mel1 sol.var matches 3 run function solstice:r3/m2_ring3
execute if score #m2pt sol.var matches 34 if score #m2len sol.var matches 2.. if score #mel1 sol.var matches 4 run function solstice:r3/m2_ring4
execute if score #m2pt sol.var matches 48 if score #m2len sol.var matches 3.. if score #mel2 sol.var matches 0 run function solstice:r3/m2_ring0
execute if score #m2pt sol.var matches 48 if score #m2len sol.var matches 3.. if score #mel2 sol.var matches 1 run function solstice:r3/m2_ring1
execute if score #m2pt sol.var matches 48 if score #m2len sol.var matches 3.. if score #mel2 sol.var matches 2 run function solstice:r3/m2_ring2
execute if score #m2pt sol.var matches 48 if score #m2len sol.var matches 3.. if score #mel2 sol.var matches 3 run function solstice:r3/m2_ring3
execute if score #m2pt sol.var matches 48 if score #m2len sol.var matches 3.. if score #mel2 sol.var matches 4 run function solstice:r3/m2_ring4
execute if score #m2pt sol.var matches 62 if score #m2len sol.var matches 4.. if score #mel3 sol.var matches 0 run function solstice:r3/m2_ring0
execute if score #m2pt sol.var matches 62 if score #m2len sol.var matches 4.. if score #mel3 sol.var matches 1 run function solstice:r3/m2_ring1
execute if score #m2pt sol.var matches 62 if score #m2len sol.var matches 4.. if score #mel3 sol.var matches 2 run function solstice:r3/m2_ring2
execute if score #m2pt sol.var matches 62 if score #m2len sol.var matches 4.. if score #mel3 sol.var matches 3 run function solstice:r3/m2_ring3
execute if score #m2pt sol.var matches 62 if score #m2len sol.var matches 4.. if score #mel3 sol.var matches 4 run function solstice:r3/m2_ring4
execute if score #m2pt sol.var matches 76 if score #m2len sol.var matches 5.. if score #mel4 sol.var matches 0 run function solstice:r3/m2_ring0
execute if score #m2pt sol.var matches 76 if score #m2len sol.var matches 5.. if score #mel4 sol.var matches 1 run function solstice:r3/m2_ring1
execute if score #m2pt sol.var matches 76 if score #m2len sol.var matches 5.. if score #mel4 sol.var matches 2 run function solstice:r3/m2_ring2
execute if score #m2pt sol.var matches 76 if score #m2len sol.var matches 5.. if score #mel4 sol.var matches 3 run function solstice:r3/m2_ring3
execute if score #m2pt sol.var matches 76 if score #m2len sol.var matches 5.. if score #mel4 sol.var matches 4 run function solstice:r3/m2_ring4
execute if score #m2pt sol.var matches 100.. run scoreboard players set #m2play sol.var 0
