execute as @a[scores={sol.role=1}] run title @s times 10 70 20
execute as @a[scores={sol.role=1}] run title @s subtitle {"text":"À l’avant : lisez les panneaux, réglez l’aiguillage.","color":"gray"}
execute as @a[scores={sol.role=1}] run title @s title {"text":"Aiguilleur","color":"aqua","bold":true}
execute as @a[scores={sol.role=2}] run title @s times 10 70 20
execute as @a[scores={sol.role=2}] run title @s subtitle {"text":"Dans la cabine : charbon, chaudière, soupape. Gardez la pression !","color":"gray"}
execute as @a[scores={sol.role=2}] run title @s title {"text":"Chauffeur","color":"gold","bold":true}
execute as @a[scores={sol.role=3}] run title @s times 10 70 20
execute as @a[scores={sol.role=3}] run title @s subtitle {"text":"À l’arrière : feuille de route, barrières, et chassez les Brumeux.","color":"gray"}
execute as @a[scores={sol.role=3}] run title @s title {"text":"Garde-barrière","color":"yellow","bold":true}
tellraw @a ["",{"text":"⚄ Tirage au sort","color":"aqua","bold":true}]
execute if score #vac1 sol.var matches 0 run tellraw @a ["",{"text":"  • ","color":"dark_gray"},{"text":"Aiguilleur","color":"aqua","bold":true},{"text":" : ","color":"gray"},{"selector":"@a[scores={sol.role=1}]","color":"white"}]
execute if score #vac1 sol.var matches 1 run tellraw @a ["",{"text":"  • ","color":"dark_gray"},{"text":"Aiguilleur","color":"aqua","bold":true},{"text":" : vacant (tout le monde peut le jouer)","color":"gray"}]
execute if score #vac2 sol.var matches 0 run tellraw @a ["",{"text":"  • ","color":"dark_gray"},{"text":"Chauffeur","color":"gold","bold":true},{"text":" : ","color":"gray"},{"selector":"@a[scores={sol.role=2}]","color":"white"}]
execute if score #vac2 sol.var matches 1 run tellraw @a ["",{"text":"  • ","color":"dark_gray"},{"text":"Chauffeur","color":"gold","bold":true},{"text":" : vacant (tout le monde peut le jouer)","color":"gray"}]
execute if score #vac3 sol.var matches 0 run tellraw @a ["",{"text":"  • ","color":"dark_gray"},{"text":"Garde-barrière","color":"yellow","bold":true},{"text":" : ","color":"gray"},{"selector":"@a[scores={sol.role=3}]","color":"white"}]
execute if score #vac3 sol.var matches 1 run tellraw @a ["",{"text":"  • ","color":"dark_gray"},{"text":"Garde-barrière","color":"yellow","bold":true},{"text":" : vacant (tout le monde peut le jouer)","color":"gray"}]
execute as @a at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.2
