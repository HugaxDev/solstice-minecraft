execute if score #spell sol.var matches 0 run return 0
scoreboard players set #spell sol.var 0
playsound minecraft:block.wood.break master @a ~ ~ ~ 1 0.6
title @a actionbar {"text":"Le plancher grince : mauvaise lettre, on recommence depuis le début.","color":"red"}
