bossbar set solstice:train visible false
kill @e[type=!player,tag=sol.r1mob]
execute if score #errors sol.var matches 0 run function solstice:challenge/grant_voie_royale
