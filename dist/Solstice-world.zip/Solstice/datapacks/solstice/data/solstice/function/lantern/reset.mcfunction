scoreboard players set #lantern sol.var 0
execute as @a run clear @s lantern[custom_data~{sol:{lantern:1b}}]
