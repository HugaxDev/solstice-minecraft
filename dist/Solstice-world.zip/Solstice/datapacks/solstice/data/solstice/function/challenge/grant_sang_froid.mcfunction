advancement grant @a only solstice:challenge/sang_froid
tellraw @a ["",{"text":"★ Défi caché relevé : ","color":"aqua","bold":true},{"text":"Sang-froid","color":"white"}]
execute as @a run function solstice:challenge/check_all
