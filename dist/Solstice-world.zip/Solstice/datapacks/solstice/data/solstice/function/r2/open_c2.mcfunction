fill 2008 111 -4 2008 113 -4 air
fill 2006 111 -4 2006 113 -4 air
fill 2007 111 -3 2007 113 -3 air
particle minecraft:electric_spark 2007.5 112 -2.5 0.6 0.8 0.6 0.1 30 force
playsound minecraft:block.iron_door.open master @a 2007 112 -3 2 0.7
