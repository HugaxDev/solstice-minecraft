scoreboard players add #mel3 sol.var 1
execute if score #mel3 sol.var matches 5.. run scoreboard players set #mel3 sol.var 0
