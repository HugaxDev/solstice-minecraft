execute if score #rt sol.var matches ..14400 run function solstice:challenge/grant_horlogerie_fine
