data modify entity @e[type=text_display,tag=sol.r1sign,limit=1] text set value '["",{"text":"Voie libre","color":"green"}]'
