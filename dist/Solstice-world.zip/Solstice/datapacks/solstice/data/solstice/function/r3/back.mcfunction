function solstice:r3/cp
scoreboard players set @s sol.cool 30
playsound minecraft:block.portal.travel master @s ~ ~ ~ 0.2 1.9
