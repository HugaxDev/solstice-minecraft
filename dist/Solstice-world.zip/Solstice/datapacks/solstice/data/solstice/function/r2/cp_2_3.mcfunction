tp @s 2000.5 121 1.5 180 0
spawnpoint @s 2000 121 1
