tag @s remove sol.dn
scoreboard players set @s sol.down 0
execute if entity @s[gamemode=spectator] run spectate
gamemode adventure @s
effect clear @s
effect give @s saturation infinite 0 true
function solstice:rooms/respawn
