scoreboard players add #ht sol.var 1
execute if score #ht sol.var matches 6000 run function solstice:hints/give1
execute if score #ht sol.var matches 9600 run function solstice:hints/give2
