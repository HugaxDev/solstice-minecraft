scoreboard players remove @s sol.t 1
execute if score @s sol.t matches 1.. unless entity @s[tag=sol.shown] run function solstice:lantern/ink_show
execute if score @s sol.t matches 0 if entity @s[tag=sol.shown] run function solstice:lantern/ink_hide
