execute if score #bopen sol.var matches 0 run return run function solstice:r1/err_cross
scoreboard players add #ev sol.var 1
scoreboard players set #signed sol.var 0
scoreboard players set #ev_cross sol.var 0
function solstice:r1/sign_free
scoreboard players set #bopen sol.var 0
scoreboard players set #crank sol.var 0
tellraw @a ["",{"text":"✔ Passage à niveau franchi.","color":"green"}]
