execute if entity @s[x=2990,y=101,z=-9,dx=2,dy=1,dz=0] if score @s sol.cool matches 0 run function solstice:r3/go1
execute if entity @s[x=2999,y=101,z=-9,dx=2,dy=1,dz=0] if score @s sol.cool matches 0 run function solstice:r3/go2
execute if entity @s[x=3008,y=101,z=-9,dx=2,dy=1,dz=0] if score @s sol.cool matches 0 run function solstice:r3/go3
execute if entity @s[x=3003,y=101,z=-34,dx=0,dy=1,dz=0] run function solstice:r3/back
execute if entity @s[x=2995,y=101,z=35,dx=0,dy=1,dz=0] run function solstice:r3/back
execute if entity @s[x=3044,y=101,z=5,dx=0,dy=1,dz=0] run function solstice:r3/back
execute if score #step sol.var matches 3 run function solstice:r3/spell_tick
