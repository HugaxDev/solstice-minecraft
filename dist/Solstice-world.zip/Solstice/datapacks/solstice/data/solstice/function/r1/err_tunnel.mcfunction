tellraw @a ["",{"text":"✖ Pas assez de pression : le train glisse en arrière dans la montée.","color":"red"}]
function solstice:r1/back
