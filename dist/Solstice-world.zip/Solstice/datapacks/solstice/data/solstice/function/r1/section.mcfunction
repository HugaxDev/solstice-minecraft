scoreboard players operation #sec sol.var = #dist sol.var
scoreboard players operation #sec sol.var /= #cSEC sol.var
scoreboard players add #sec sol.var 1
execute if score #sec sol.var matches 10.. run scoreboard players set #sec sol.var 9
execute unless score #sec sol.var = #step sol.var run function solstice:r1/new_section
