tellraw @a ["",{"text":"Au-delà de la nuit, une vallée où les saisons se sont mélangées.","color":"white","italic":true}]
execute as @a at @s run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.8 0.9
