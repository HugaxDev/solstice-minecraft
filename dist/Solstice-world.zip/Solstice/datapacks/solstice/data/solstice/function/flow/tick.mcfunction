execute store result score #np sol.var if entity @a
execute if score #m20 sol.var matches 13 store result score #diff sol.var run difficulty
execute if score #m20 sol.var matches 13 if score #diff sol.var matches 0 run function solstice:system/not_peaceful
execute if score #started sol.var matches 1 if score #ended sol.var matches 0 run scoreboard players add #gtime sol.var 1
execute if score #trans sol.var matches 1.. run return run function solstice:flow/trans_tick
execute if score #pstart sol.var matches 1 run return run function solstice:flow/start_room
scoreboard players add #rt sol.var 1
function solstice:hints/tick
function solstice:rooms/tick
function solstice:lantern/tick
execute if score #ended sol.var matches 1 if score #room sol.var matches 7 run function solstice:end/tick
execute if score #m20 sol.var matches 0 run bossbar set solstice:obj players @a
