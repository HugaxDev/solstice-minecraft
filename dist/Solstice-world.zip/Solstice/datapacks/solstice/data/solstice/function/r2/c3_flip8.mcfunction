scoreboard players add #c3_8 sol.var 1
execute if score #c3_8 sol.var matches 2.. run scoreboard players set #c3_8 sol.var 0
execute if score #c3_8 sol.var matches 1 run setblock 2015 122 1 sea_lantern
execute if score #c3_8 sol.var matches 0 run setblock 2015 122 1 black_concrete
