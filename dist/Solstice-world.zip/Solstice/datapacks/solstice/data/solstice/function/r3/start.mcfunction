function solstice:r3/reset
scoreboard players set #step sol.var 1
function solstice:r3/obj
function solstice:roles/draw
function solstice:r3/announce
tellraw @a ["",{"text":"Maître Orel","color":"gold","bold":true},{"text":" » ","color":"dark_gray"},{"text":"Mon vieil atelier ! Pour voir ce que le temps a caché, il nous faut la Lanterne des Saisons. Trois pièces, trois missions, une par personne. Les portes sont au nord. Et on assemble ENSEMBLE, hein !","color":"yellow"}]
