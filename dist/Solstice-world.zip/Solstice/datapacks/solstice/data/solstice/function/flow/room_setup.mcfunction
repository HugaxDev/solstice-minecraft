scoreboard players set #rt sol.var 0
scoreboard players set #rdeaths sol.var 0
scoreboard players set #step sol.var 0
function solstice:hints/reset
kill @e[type=!player,tag=sol.mob]
execute if score #room sol.var matches 0 run time set 13000
execute if score #room sol.var matches 0 run scoreboard players set #combat sol.var 0
execute if score #room sol.var matches 0 run bossbar set solstice:obj color yellow
execute if score #room sol.var matches 0 run gamerule naturalRegeneration true
execute if score #room sol.var matches 1 run time set 18000
execute if score #room sol.var matches 1 run scoreboard players set #combat sol.var 0
execute if score #room sol.var matches 1 run bossbar set solstice:obj color blue
execute if score #room sol.var matches 1 run gamerule naturalRegeneration true
execute if score #room sol.var matches 2 run time set 1000
execute if score #room sol.var matches 2 run scoreboard players set #combat sol.var 0
execute if score #room sol.var matches 2 run bossbar set solstice:obj color yellow
execute if score #room sol.var matches 2 run gamerule naturalRegeneration true
execute if score #room sol.var matches 3 run time set 16000
execute if score #room sol.var matches 3 run scoreboard players set #combat sol.var 0
execute if score #room sol.var matches 3 run bossbar set solstice:obj color yellow
execute if score #room sol.var matches 3 run gamerule naturalRegeneration true
execute if score #room sol.var matches 4 run time set 13500
execute if score #room sol.var matches 4 run scoreboard players set #combat sol.var 1
execute if score #room sol.var matches 4 run bossbar set solstice:obj color red
execute if score #room sol.var matches 4 run gamerule naturalRegeneration false
execute if score #room sol.var matches 5 run time set 18000
execute if score #room sol.var matches 5 run scoreboard players set #combat sol.var 0
execute if score #room sol.var matches 5 run bossbar set solstice:obj color purple
execute if score #room sol.var matches 5 run gamerule naturalRegeneration true
execute if score #room sol.var matches 6 run time set 6000
execute if score #room sol.var matches 6 run scoreboard players set #combat sol.var 0
execute if score #room sol.var matches 6 run bossbar set solstice:obj color green
execute if score #room sol.var matches 6 run gamerule naturalRegeneration true
execute if score #room sol.var matches 7 run time set 18000
execute if score #room sol.var matches 7 run scoreboard players set #combat sol.var 1
execute if score #room sol.var matches 7 run bossbar set solstice:obj color pink
execute if score #room sol.var matches 7 run gamerule naturalRegeneration false
execute if score #room sol.var matches 8 run time set 1000
execute if score #room sol.var matches 8 run scoreboard players set #combat sol.var 0
execute if score #room sol.var matches 8 run bossbar set solstice:obj color green
execute if score #room sol.var matches 8 run gamerule naturalRegeneration true
