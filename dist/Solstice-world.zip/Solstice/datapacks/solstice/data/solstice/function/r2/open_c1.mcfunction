fill 2012 101 -4 2012 103 -4 air
fill 2014 101 -4 2014 103 -4 air
fill 2013 101 -3 2013 103 -3 air
particle minecraft:electric_spark 2013.5 102 -2.5 0.6 0.8 0.6 0.1 30 force
playsound minecraft:block.iron_door.open master @a 2013 102 -3 2 0.7
