scoreboard players set #signed sol.var 1
function solstice:r1/sign/12
scoreboard players set #ev_cross sol.var 0
