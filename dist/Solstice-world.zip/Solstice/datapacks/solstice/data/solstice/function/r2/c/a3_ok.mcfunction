execute if score #a3lock sol.var matches 1.. run return run title @s actionbar {"text":"Le mécanisme est bloqué. Patientez…","color":"red"}
execute if score #a3c sol.var matches 0 if block 1988 122 4 lever[powered=true] if block 1990 122 4 lever[powered=false] if block 1992 122 4 lever[powered=true] run return run function solstice:r2/solve_a3
execute if score #a3c sol.var matches 1 if block 1988 122 4 lever[powered=false] if block 1990 122 4 lever[powered=false] if block 1992 122 4 lever[powered=true] run return run function solstice:r2/solve_a3
execute if score #a3c sol.var matches 2 if block 1988 122 4 lever[powered=true] if block 1990 122 4 lever[powered=true] if block 1992 122 4 lever[powered=false] run return run function solstice:r2/solve_a3
execute if score #a3c sol.var matches 3 if block 1988 122 4 lever[powered=false] if block 1990 122 4 lever[powered=true] if block 1992 122 4 lever[powered=false] run return run function solstice:r2/solve_a3
function solstice:r2/a3_wrong
