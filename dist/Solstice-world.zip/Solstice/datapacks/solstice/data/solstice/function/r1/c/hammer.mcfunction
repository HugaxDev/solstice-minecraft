execute if score @s sol.cool matches 1.. run return 0
scoreboard players set @s sol.cool 10
tellraw @s ["",{"text":"Un manche dépasse du charbon… Vous tirez : un marteau de forgeron gravé « B. » !","color":"gray","italic":true}]
function solstice:story/found_marteau
kill @e[type=!player,tag=sol.r1ham]
