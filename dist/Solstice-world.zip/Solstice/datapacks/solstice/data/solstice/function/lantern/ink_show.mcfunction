tag @s add sol.shown
data merge entity @s {start_interpolation:0,interpolation_duration:8,transformation:{scale:[1f,1f,1f]}}
execute at @s run particle minecraft:enchant ~ ~ ~ 0.5 0.3 0.5 0.5 20
execute at @s run playsound minecraft:block.amethyst_block.chime master @a[distance=..8] ~ ~ ~ 0.5 1.8
execute if entity @s[tag=sol.once] run function solstice:lantern/ink_once
