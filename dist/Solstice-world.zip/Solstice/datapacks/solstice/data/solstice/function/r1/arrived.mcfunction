scoreboard players set #dist sol.var 12600
title @a times 10 60 20
title @a subtitle {"text":"Gare du Pic du Solstice","color":"gray"}
title @a title {"text":"Terminus !","color":"aqua","bold":true}
tellraw @a ["",{"text":"Maître Orel","color":"gold","bold":true},{"text":" » ","color":"dark_gray"},{"text":"Bravo ! Pas un mort, et presque pas de charbon sur les banquettes. Descendez, la Tour vous attend.","color":"yellow"}]
function solstice:flow/complete
