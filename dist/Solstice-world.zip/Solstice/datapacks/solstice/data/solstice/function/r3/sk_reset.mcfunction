scoreboard players set #cr1x sol.var 1
scoreboard players set #cr2x sol.var 4
scoreboard players set #cr1z sol.var 1
scoreboard players set #cr2z sol.var 3
fill 2997 101 -44 3003 101 -38 air replace barrier
function solstice:r3/sk_show
