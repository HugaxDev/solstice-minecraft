execute if score #slot1 sol.var matches 1 as @a[tag=sol.ro1] run give @s minecraft:iron_bars[custom_name='{"text":"Cage de laiton","color":"gold","italic":false}',lore=['{"text":"Une pièce de la Lanterne des Saisons.","color":"gray","italic":true}'],custom_data={sol:{comp1:1b}},enchantment_glint_override=true,max_stack_size=1]
execute if score #slot2 sol.var matches 1 as @a[tag=sol.ro2] run give @s minecraft:string[custom_name='{"text":"Mèche éternelle","color":"aqua","italic":false}',lore=['{"text":"Une pièce de la Lanterne des Saisons.","color":"gray","italic":true}'],custom_data={sol:{comp2:1b}},enchantment_glint_override=true,max_stack_size=1]
execute if score #slot3 sol.var matches 1 as @a[tag=sol.ro3] run give @s minecraft:glass_pane[custom_name='{"text":"Verre de lune","color":"light_purple","italic":false}',lore=['{"text":"Une pièce de la Lanterne des Saisons.","color":"gray","italic":true}'],custom_data={sol:{comp3:1b}},enchantment_glint_override=true,max_stack_size=1]
execute if score #slot1 sol.var matches 1 unless entity @a[tag=sol.ro1] as @a run give @s minecraft:iron_bars[custom_name='{"text":"Cage de laiton","color":"gold","italic":false}',lore=['{"text":"Une pièce de la Lanterne des Saisons.","color":"gray","italic":true}'],custom_data={sol:{comp1:1b}},enchantment_glint_override=true,max_stack_size=1]
execute if score #slot2 sol.var matches 1 unless entity @a[tag=sol.ro2] as @a run give @s minecraft:string[custom_name='{"text":"Mèche éternelle","color":"aqua","italic":false}',lore=['{"text":"Une pièce de la Lanterne des Saisons.","color":"gray","italic":true}'],custom_data={sol:{comp2:1b}},enchantment_glint_override=true,max_stack_size=1]
execute if score #slot3 sol.var matches 1 unless entity @a[tag=sol.ro3] as @a run give @s minecraft:glass_pane[custom_name='{"text":"Verre de lune","color":"light_purple","italic":false}',lore=['{"text":"Une pièce de la Lanterne des Saisons.","color":"gray","italic":true}'],custom_data={sol:{comp3:1b}},enchantment_glint_override=true,max_stack_size=1]
scoreboard players set #slot1 sol.var 0
scoreboard players set #slot2 sol.var 0
scoreboard players set #slot3 sol.var 0
kill @e[type=!player,tag=sol.placed]
playsound minecraft:block.anvil.land master @a ~ ~ ~ 0.5 0.8
tellraw @a ["",{"text":"Les pièces glissent de l’établi : elles doivent être posées ENSEMBLE (en même temps).","color":"red"}]
