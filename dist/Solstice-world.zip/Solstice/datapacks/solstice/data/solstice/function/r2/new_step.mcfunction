scoreboard players operation #step sol.var = #lv sol.var
function solstice:hints/reset
function solstice:r2/obj
