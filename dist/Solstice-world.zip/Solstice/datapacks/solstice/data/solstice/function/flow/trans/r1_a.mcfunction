title @a times 10 50 10
title @a subtitle {"text":"L’Express du Solstice","color":"gray"}
title @a title {"text":"Salle terminée","color":"aqua","bold":true}
