function solstice:story/found_mot
