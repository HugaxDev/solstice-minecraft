execute if score #s_a2 sol.var matches 1 run return 0
scoreboard players set #s_a2 sol.var 1
function solstice:r2/open_c2
tellraw @a ["",{"text":"⚙ ","color":"gold"},{"text":"Puits du Cuivre","color":"gold"},{"text":" : mécanisme résolu → la grille du ","color":"gray"},{"text":"puits du Fer","color":"gray"},{"text":" (niveau 2) s’ouvre !","color":"gray"}]
execute as @a at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.8 1.4
function solstice:r2/progress
