execute if entity @s[gamemode=!spectator] run function solstice:flow/bounds
function solstice:rooms/ptick
