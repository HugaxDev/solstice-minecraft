scoreboard players set #step sol.var 1
function solstice:hints/reset
tellraw @a ["",{"text":"Maître Orel","color":"gold","bold":true},{"text":" » ","color":"dark_gray"},{"text":"Chauffeur : du charbon dans la chaudière ! Aiguilleur : les yeux sur les panneaux ! Garde : la feuille de route !","color":"yellow"}]
title @a times 5 40 10
title @a subtitle {"text":"L’Express s’élance","color":"gray"}
title @a title {"text":"Tchou-tchou !","color":"aqua","bold":true}
