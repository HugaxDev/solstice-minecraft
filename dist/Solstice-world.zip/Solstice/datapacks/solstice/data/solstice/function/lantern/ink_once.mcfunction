tag @s remove sol.once
execute if entity @s[tag=sol.i_mot] run function solstice:lantern/once/mot
execute if entity @s[tag=sol.i_plan] run function solstice:lantern/once/plan
