execute if score #lantern sol.var matches 1 if score #m20 sol.var matches 7 run function solstice:lantern/keeper
execute if score #m4 sol.var matches 0 run function solstice:lantern/reveal
