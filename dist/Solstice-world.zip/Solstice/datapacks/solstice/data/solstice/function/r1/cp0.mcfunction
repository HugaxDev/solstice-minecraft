tp @s 1000.5 101 0.5 90 0
spawnpoint @s 1000 101 0
