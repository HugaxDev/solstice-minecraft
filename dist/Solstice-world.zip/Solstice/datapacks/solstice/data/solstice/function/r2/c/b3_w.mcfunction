scoreboard players set #okm sol.var 0
execute if score #b3m sol.var matches 0 if score #mx sol.var matches 1 if score #my sol.var matches 0 run scoreboard players set #okm sol.var 1
execute if score #b3m sol.var matches 0 if score #mx sol.var matches 1 if score #my sol.var matches 1 run scoreboard players set #okm sol.var 1
execute if score #b3m sol.var matches 0 if score #mx sol.var matches 2 if score #my sol.var matches 0 run scoreboard players set #okm sol.var 1
execute if score #b3m sol.var matches 0 if score #mx sol.var matches 2 if score #my sol.var matches 2 run scoreboard players set #okm sol.var 1
execute if score #b3m sol.var matches 0 if score #mx sol.var matches 2 if score #my sol.var matches 3 run scoreboard players set #okm sol.var 1
execute if score #b3m sol.var matches 0 if score #mx sol.var matches 3 if score #my sol.var matches 0 run scoreboard players set #okm sol.var 1
execute if score #b3m sol.var matches 0 if score #mx sol.var matches 3 if score #my sol.var matches 1 run scoreboard players set #okm sol.var 1
execute if score #b3m sol.var matches 0 if score #mx sol.var matches 3 if score #my sol.var matches 3 run scoreboard players set #okm sol.var 1
execute if score #b3m sol.var matches 1 if score #mx sol.var matches 1 if score #my sol.var matches 0 run scoreboard players set #okm sol.var 1
execute if score #b3m sol.var matches 1 if score #mx sol.var matches 2 if score #my sol.var matches 0 run scoreboard players set #okm sol.var 1
execute if score #b3m sol.var matches 1 if score #mx sol.var matches 2 if score #my sol.var matches 3 run scoreboard players set #okm sol.var 1
execute if score #b3m sol.var matches 1 if score #mx sol.var matches 3 if score #my sol.var matches 1 run scoreboard players set #okm sol.var 1
execute if score #b3m sol.var matches 1 if score #mx sol.var matches 3 if score #my sol.var matches 2 run scoreboard players set #okm sol.var 1
execute if score #b3m sol.var matches 1 if score #mx sol.var matches 3 if score #my sol.var matches 3 run scoreboard players set #okm sol.var 1
execute if score #b3m sol.var matches 2 if score #mx sol.var matches 1 if score #my sol.var matches 0 run scoreboard players set #okm sol.var 1
execute if score #b3m sol.var matches 2 if score #mx sol.var matches 1 if score #my sol.var matches 3 run scoreboard players set #okm sol.var 1
execute if score #b3m sol.var matches 2 if score #mx sol.var matches 2 if score #my sol.var matches 0 run scoreboard players set #okm sol.var 1
execute if score #b3m sol.var matches 2 if score #mx sol.var matches 3 if score #my sol.var matches 1 run scoreboard players set #okm sol.var 1
execute if score #b3m sol.var matches 2 if score #mx sol.var matches 3 if score #my sol.var matches 2 run scoreboard players set #okm sol.var 1
execute if score #b3m sol.var matches 2 if score #mx sol.var matches 3 if score #my sol.var matches 3 run scoreboard players set #okm sol.var 1
execute if score #okm sol.var matches 1 run scoreboard players remove #mx sol.var 1
execute if score #okm sol.var matches 0 run function solstice:r2/b3_bump
execute if score #okm sol.var matches 1 run playsound minecraft:block.stone.step master @a ~ ~ ~ 1 1
function solstice:r2/mk_show
execute if score #mx sol.var matches 3 if score #my sol.var matches 0 run function solstice:r2/solve_b3
