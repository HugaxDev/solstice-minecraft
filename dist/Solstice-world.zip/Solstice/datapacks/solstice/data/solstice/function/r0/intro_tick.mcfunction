scoreboard players add #r0t sol.var 1
execute if score #r0t sol.var matches 20 run function solstice:r0/intro/t20
execute if score #r0t sol.var matches 100 run function solstice:r0/intro/t100
execute if score #r0t sol.var matches 220 run function solstice:r0/intro/t220
execute if score #r0t sol.var matches 360 run function solstice:r0/intro/t360
execute if score #r0t sol.var matches 500 run function solstice:r0/intro/t500
execute if score #r0t sol.var matches 640 run function solstice:r0/intro/t640
execute if score #r0t sol.var matches 760 run function solstice:r0/intro/t760
execute if score #r0t sol.var matches 770 run function solstice:r0/intro/t770
