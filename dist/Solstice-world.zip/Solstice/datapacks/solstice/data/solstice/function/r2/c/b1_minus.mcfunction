scoreboard players remove #b1c sol.var 1
execute if score #b1c sol.var matches ..-1 run scoreboard players set #b1c sol.var 9
playsound minecraft:block.wooden_button.click_on master @a ~ ~ ~ 1 0.9
function solstice:r2/b1_show
