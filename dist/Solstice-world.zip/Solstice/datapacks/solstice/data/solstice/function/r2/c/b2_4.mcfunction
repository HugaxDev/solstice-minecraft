scoreboard players operation #b2e sol.var *= #c10 sol.var
scoreboard players add #b2e sol.var 4
scoreboard players add #b2n sol.var 1
playsound minecraft:block.stone_button.click_on master @a ~ ~ ~ 1 1.1
function solstice:r2/b2_show
execute if score #b2n sol.var matches 4.. run function solstice:r2/b2_check
