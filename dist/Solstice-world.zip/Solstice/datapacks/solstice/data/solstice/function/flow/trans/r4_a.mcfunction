title @a times 10 50 10
title @a subtitle {"text":"Le Siège du Sanctuaire","color":"gray"}
title @a title {"text":"Salle terminée","color":"red","bold":true}
