scoreboard players remove @s sol.down 1
execute if entity @s[gamemode=spectator] if score #m20 sol.var matches 0 run spectate @a[tag=!sol.dn,gamemode=!spectator,sort=nearest,limit=1] @s
execute if score @s sol.down matches 0 run function solstice:player/down_end
