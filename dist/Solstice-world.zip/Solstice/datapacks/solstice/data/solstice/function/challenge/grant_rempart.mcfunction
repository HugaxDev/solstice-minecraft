advancement grant @a only solstice:challenge/rempart
tellraw @a ["",{"text":"★ Défi caché relevé : ","color":"aqua","bold":true},{"text":"Rempart","color":"white"}]
execute as @a run function solstice:challenge/check_all
