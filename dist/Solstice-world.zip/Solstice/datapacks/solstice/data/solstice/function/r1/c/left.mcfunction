execute if score @s sol.cool matches 1.. run return 0
scoreboard players set @s sol.cool 6
execute unless entity @s[tag=sol.ro1] run return run title @s actionbar {"text":"Ce n’est pas votre poste : c’est celui du Aiguilleur.","color":"red"}
scoreboard players set #switch sol.var 0
function solstice:r1/show_switch
playsound minecraft:block.lever.click master @a ~ ~ ~ 1 0.8
title @s actionbar {"text":"Aiguillage : voie de GAUCHE","color":"aqua"}
