scoreboard players set #signed sol.var 1
function solstice:r1/sign/14
scoreboard players set #ev_cross sol.var 0
