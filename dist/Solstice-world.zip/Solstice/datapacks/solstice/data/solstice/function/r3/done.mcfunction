execute if score #r3done sol.var matches 1 run return 0
scoreboard players set #r3done sol.var 1
title @a times 10 60 20
title @a subtitle {"text":"La grande horloge s’ouvre","color":"gray"}
title @a title {"text":"TEMPS","color":"gold","bold":true}
tellraw @a ["",{"text":"Maître Orel","color":"gold","bold":true},{"text":" » ","color":"dark_gray"},{"text":"« Temps ». Évidemment. J’ai toujours manqué d’imagination pour les mots de passe.","color":"yellow"}]
function solstice:flow/complete
