tp @s 1016.5 101 0.5 -90 0
spawnpoint @s 1016 101 0
