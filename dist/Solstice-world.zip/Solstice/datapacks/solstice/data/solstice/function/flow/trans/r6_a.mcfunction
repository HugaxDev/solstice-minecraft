title @a times 10 50 10
title @a subtitle {"text":"Les Quatre Saisons","color":"gray"}
title @a title {"text":"Salle terminée","color":"green","bold":true}
