fill 1992 101 -4 1992 103 -4 air
fill 1994 101 -4 1994 103 -4 air
fill 1993 101 -3 1993 103 -3 air
particle minecraft:electric_spark 1993.5 102 -2.5 0.6 0.8 0.6 0.1 30 force
playsound minecraft:block.iron_door.open master @a 1993 102 -3 2 0.7
