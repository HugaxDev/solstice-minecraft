scoreboard players add #ev sol.var 1
scoreboard players set #signed sol.var 0
scoreboard players set #ev_cross sol.var 0
function solstice:r1/sign_free
scoreboard players set #lim sol.var 0
tellraw @a ["",{"text":"✔ Zone lente franchie.","color":"green"}]
