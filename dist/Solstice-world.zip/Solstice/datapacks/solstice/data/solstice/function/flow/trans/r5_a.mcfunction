title @a times 10 50 10
title @a subtitle {"text":"La Nuit la plus longue","color":"gray"}
title @a title {"text":"Salle terminée","color":"dark_purple","bold":true}
