function solstice:r7/seasons2
function solstice:r7/fireworks
