title @s times 20 80 30
title @s subtitle {"text":"Brumeval, la veille du dernier jour","color":"gray"}
title @s title {"text":"SOLSTICE","color":"gold","bold":true}
tellraw @s ["",{"text":"Trois voyageurs sont attendus à Brumeval. L’aventure commence quand vous êtes tous là.","color":"gray","italic":true}]
playsound minecraft:block.bell.resonate master @s ~ ~ ~ 0.8 0.8
