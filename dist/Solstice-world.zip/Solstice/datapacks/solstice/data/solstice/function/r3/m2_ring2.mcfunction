playsound minecraft:block.note_block.bell master @a 3000 102 46 2 1.05
particle minecraft:note 3000.5 103.2 46.5 0.2 0.2 0.2 1 6 force
particle minecraft:end_rod 3000.5 102.5 46.5 0.3 0.3 0.3 0.02 10 force
