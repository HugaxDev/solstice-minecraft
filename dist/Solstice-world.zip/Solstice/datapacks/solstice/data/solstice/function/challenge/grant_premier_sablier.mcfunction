advancement grant @a only solstice:challenge/premier_sablier
tellraw @a ["",{"text":"★ Défi caché relevé : ","color":"aqua","bold":true},{"text":"Le temps d’un sablier","color":"white"}]
execute as @a run function solstice:challenge/check_all
