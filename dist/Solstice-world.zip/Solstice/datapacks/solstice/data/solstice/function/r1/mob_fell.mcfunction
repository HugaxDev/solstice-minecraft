tp @s ~ -100 ~
kill @s
tellraw @a ["",{"text":"Un Brumeux est passé par-dessus bord.","color":"gray"}]
