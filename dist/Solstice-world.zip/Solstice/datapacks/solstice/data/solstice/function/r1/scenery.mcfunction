execute if score #speed sol.var matches 1 as @e[type=block_display,tag=sol.scen] at @s run tp @s ~0.6 ~ ~
execute if score #speed sol.var matches 2 as @e[type=block_display,tag=sol.scen] at @s run tp @s ~1.2 ~ ~
execute if score #speed sol.var matches 3 as @e[type=block_display,tag=sol.scen] at @s run tp @s ~1.9 ~ ~
execute as @e[type=block_display,tag=sol.scen] at @s if entity @s[x=1046,y=80,z=-30,dx=20,dy=40,dz=60] run tp @s ~-94 ~ ~
execute if score #speed sol.var matches 1.. run particle minecraft:campfire_cosy_smoke 982.5 108 0.5 0.3 0.3 0.3 0.02 3 force
execute if score #speed sol.var matches 1.. as @a[tag=sol.ro1] at @s run playsound minecraft:entity.minecart.riding ambient @s ~ ~ ~ 0.15 0.8
