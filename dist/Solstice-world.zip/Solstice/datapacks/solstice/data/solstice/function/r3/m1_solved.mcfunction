scoreboard players set #m1done sol.var 1
setblock 2998 101 -35 air
execute as @a[tag=sol.ro1] at @s run playsound minecraft:block.chest.open master @s ~ ~ ~ 1 1
tellraw @a ["",{"text":"✦ Grenier : les caisses sont en place, la vitrine s’ouvre.","color":"gold"}]
