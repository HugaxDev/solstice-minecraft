tellraw @a ["",{"text":"✖ La chaudière s’est éteinte… le train s’arrête et recule au dernier tronçon.","color":"red"}]
function solstice:r1/back
