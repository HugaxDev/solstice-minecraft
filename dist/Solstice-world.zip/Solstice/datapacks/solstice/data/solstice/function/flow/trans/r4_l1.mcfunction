tellraw @a ["",{"text":"Un escalier descend vers l’obscurité. Il y fait… nuit.","color":"white","italic":true}]
execute as @a at @s run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.8 0.9
