fill 2002 121 -4 2002 123 -4 air
fill 2004 121 -4 2004 123 -4 air
fill 2003 121 -3 2003 123 -3 air
particle minecraft:electric_spark 2003.5 122 -2.5 0.6 0.8 0.6 0.1 30 force
playsound minecraft:block.iron_door.open master @a 2003 122 -3 2 0.7
