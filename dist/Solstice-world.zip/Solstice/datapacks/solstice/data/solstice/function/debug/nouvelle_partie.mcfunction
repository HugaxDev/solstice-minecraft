function solstice:flow/new_game
tellraw @a ["",{"text":"[debug] Nouvelle partie.","color":"red"}]
