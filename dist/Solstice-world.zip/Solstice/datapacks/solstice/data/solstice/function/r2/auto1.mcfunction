function solstice:r2/solve_a1
function solstice:r2/solve_a2
function solstice:r2/solve_a3
tellraw @a ["",{"text":"[debug] Puits du Cuivre vacant : l’automate d’Orel résout ses mécanismes.","color":"red"}]
